<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Amandla High School Locker System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap JS  -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">

    <!-- JS FILE FOR FUNCTIONS -->
  <script src="./js/limbo.js"></script>
      <!-- JS FILE FOR PARENTSLOGIC -->
  <script src="./js/parent.js"></script>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Google Font for School look -->
  <link href="https://fonts.googleapis.com/css2?family=Feeling:%2FExpressive%2FCalm:wght@600&display=swap" rel="stylesheet">

  <style>

    .locker-loading {
    border-radius: 20px;
    border: 3px solid #b71c1c;
    background: linear-gradient(145deg, #f9f9f9, #e0e0e0);
    box-shadow: 6px 6px 15px rgba(0,0,0,0.3), -4px -4px 10px rgba(255,255,255,0.7);
    padding: 30px;
    }


    .locker-spinner {
    width: 60px;
    height: 60px;
    border: 6px solid #ccc;
    border-top: 6px solid #b71c1c;
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin: 0 auto;
    }

    @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
    }


    .locker-alert {
    border-radius: 20px;
    border: 3px solid #b71c1c;
    background: linear-gradient(145deg, #f9f9f9, #e0e0e0);
    box-shadow: 6px 6px 15px rgba(0,0,0,0.3), -4px -4px 10px rgba(255,255,255,0.7);
    }
    .locker-header {
    border-bottom: 2px solid #ccc;
    border-top-left-radius: 18px;
    border-top-right-radius: 18px;
    background: #b71c1c;
    color: #fff;
    }

    body {
      background: linear-gradient(135deg, #eec6c6ff, #f5f5f5); 
      font-family: 'Edu SA Beginner', cursive;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
    }
    .portal-card {
      background: #fff;
      border-radius: 15px;
      padding: 30px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.15);
      max-width: 420px;
      width: 100%;
      text-align: center;
    }
    .portal-btn {
      margin: 10px 0;
      width: 100%;
    }
    .form-control {
      border-radius: 10px;
    }
    .modal-content {
      border-radius: 15px;
    }
    .system-title {
      font-size: 1.6rem;
      font-weight: bold;
      margin-bottom: 20px;
      color: #b71c1c;
    }
  </style>
</head>
<body>


  <div id="portal-selection" class="portal-card">
    <div class="system-title">Amandla High School<br>Locker System</div>
    <h4 class="mb-4">Select Portal</h4>
    <button class="btn btn-danger portal-btn" onclick="showLogin('parent')">Parent Portal</button>
    <button class="btn btn-secondary portal-btn" onclick="showLogin('admin')">Administrator Portal</button>
  </div>


  <div id="parent-login" class="portal-card d-none">
    <div class="system-title">Amandla High School<br>Locker System</div>
    <h4 class="mb-3">Parent Login</h4>
    <div class="mb-3">
      <input type="email" class="form-control" placeholder="Email">
    </div>
    <div class="mb-3 input-group">
      <input type="password" class="form-control" placeholder="Password" id="parentPassword">
      <button class="btn btn-outline-secondary" type="button" onclick="togglePassword('parentPassword')">👁</button>
    </div>
<button class="btn btn-danger w-100 mb-3" onclick="parentLogin()">Login</button>

    <p>Don't have an account yet? <a href="#" data-bs-toggle="modal" data-bs-target="#parentRegister">Create one</a></p>
  </div>
  

<div class="modal fade" id="lockerLoading" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content locker-loading">
      <div class="modal-body text-center">
        <div class="locker-spinner"></div>
        <h5 class="mt-3">Unlocking Locker…</h5>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="lockerAlert" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content locker-alert">
      <div class="modal-header locker-header">
        <h5 class="modal-title" id="lockerAlertTitle">Locker Alert</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="lockerAlertMessage">
        Default Locker.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

  <div id="admin-login" class="portal-card d-none">
    <div class="system-title">Amandla High School<br>Locker System</div>
    <h4 class="mb-3">Admin Login</h4>
    <div class="mb-3">
      <input type="email" class="form-control" placeholder="Email">
    </div>
    <div class="mb-3 input-group">
      <input type="password" class="form-control" placeholder="Password" id="adminPassword">
      <button class="btn btn-outline-secondary" type="button" onclick="togglePassword('adminPassword')">👁</button>
    </div>
<button class="btn btn-danger w-100" onclick="adminLogin()">Login</button>
  </div>


  <div class="modal fade" id="parentRegister" tabindex="-1" aria-labelledby="registerModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header bg-danger text-white">
          <h5 class="modal-title">Parent Registration</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
            <form id="parentRegisterForm">
            <div class="mb-2"><input type="text" class="form-control" name="Name" placeholder="Name"></div>
            <div class="mb-2"><input type="text" class="form-control" name="Surname" placeholder="Surname"></div>
            <div class="mb-2"><input type="text" class="form-control" name="Address" placeholder="Address"></div>
            <div class="mb-2"><input type="text" class="form-control" name="City" placeholder="City"></div>
            <div class="mb-2"><input type="text" class="form-control" name="Suburb" placeholder="Suburb"></div>
            <div class="mb-2"><input type="text" class="form-control" name="Town" placeholder="Town"></div>
            <div class="mb-2"><input type="text" class="form-control" name="PostalCode" placeholder="Postal Code"></div>
            <div class="mb-2"><input type="email" class="form-control" name="Email" placeholder="Email"></div>
            <div class="mb-2"><input type="tel" class="form-control" name="Cellphone" placeholder="Cellphone"></div>
            <div class="mb-2 input-group">
                <input type="password" class="form-control" name="Password" placeholder="Password" id="registerPassword">
                <button class="btn btn-outline-secondary" type="button" onclick="togglePassword('registerPassword')">👁</button>
            </div>
            <button type="submit" class="btn btn-danger w-100">Register</button>
            </form>
        </div>
      </div>
    </div>
  </div>


</body>
</html>
