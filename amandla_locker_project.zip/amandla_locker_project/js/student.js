document.addEventListener("DOMContentLoaded", () => {
  loadStudents();

  // ===========================
  // ADD STUDENT
  // ===========================
  const addStudentForm = document.getElementById("addStudentForm");
  if (addStudentForm) {
    addStudentForm.addEventListener("submit", async (e) => {
      e.preventDefault();

      let formData = new FormData(addStudentForm);


      showLockerLoading("Adding Student...");

      try {
        let response = await fetch("./backend/add_student.php", {
          method: "POST",
          body: formData
        });
        let result = await response.json();

        hideLockerLoading();

        if (result.status === "success") {
          bootstrap.Modal.getInstance(document.getElementById("addStudentModal")).hide();
          addStudentForm.reset();
          loadStudents();
          showLockerAlert("success", "Student added successfully!");
        } else {
          showLockerAlert("error", result.message || "Failed to add student.");
        }
      } catch (err) {
        hideLockerLoading();
        showLockerAlert("error", "Error adding student: " + err.message);
      }
    });
  }

  // ===========================
  // EDIT STUDENT
  // ===========================
  const editForm = document.getElementById("editStudentForm");
  if (editForm) {
    editForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      let formData = new FormData(editForm);

      showLockerLoading("Updating Student...");

      try {
        let response = await fetch("./backend/edit_student.php", {
          method: "POST",
          body: formData
        });
        let result = await response.json();

        hideLockerLoading();

        if (result.status === "success") {
          bootstrap.Modal.getInstance(document.getElementById("editStudentModal")).hide();
          loadStudents();
          showLockerAlert("success", "Student updated successfully!");
        } else {
          showLockerAlert("error", result.message || "Update failed.");
        }
      } catch (err) {
        hideLockerLoading();
        showLockerAlert("error", "Error updating student: " + err.message);
      }
    });
  }
});

// ===========================
// LOAD STUDENTS
// ===========================
async function loadStudents() {
  showLockerLoading("Loading students...");


  const forceClose = setTimeout(() => hideLockerLoading(), 2000);
  try {
    let response = await fetch("./backend/get_students.php");
    let students = await response.json();
    hideLockerLoading();

    let tbody = document.getElementById("studentsTableBody");
    tbody.innerHTML = "";

    if (!students || students.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6" class="text-center">No students found</td></tr>`;
      return;
    }

    students.forEach(st => {
      tbody.innerHTML += `
        <tr>

          <td>${st.Name}</td>
          <td>${st.Surname}</td>
          <td>${st.Grade}</td>
          <td>${st.DateOfBirth}</td>
          <td>
            <button class="btn btn-sm btn-warning" 
              onclick="editStudent(${st.StudentID}, '${st.Name}', '${st.Surname}', '${st.Grade}', '${st.DateOfBirth}')">
              Edit
            </button>
            <button class="btn btn-sm btn-danger" onclick="deleteStudent(${st.StudentID})">Delete</button>
          </td>
        </tr>`;
    });

  } catch (err) {
    hideLockerLoading();
    showLockerAlert("error", "Error loading students: " + err.message);
  }
}
// ===========================
// DELETE STUDENT (CONFIRMATION MODAL)
// ===========================
function deleteStudent(id) {
  showLockerConfirm("Are you sure you want to delete this student?", async () => {
    showLockerLoading("Deleting student...");

    try {
      let formData = new FormData();
      formData.append("StudentID", id);

      let response = await fetch("./backend/delete_student.php", {
        method: "POST",
        body: formData
      });
      let result = await response.json();

      hideLockerLoading();

      if (result.status === "success") {
        loadStudents();
        showLockerAlert("success", "Student deleted successfully!");
      } else {
        showLockerAlert("error", result.message || "Failed to delete student.");
      }
    } catch (err) {
      hideLockerLoading();
      showLockerAlert("error", "Error deleting student: " + err.message);
    }
  });
}


// ===========================
// OPEN EDIT MODAL
// ===========================
function editStudent(id, name, surname, grade, dob) {
  document.getElementById("editStudentID").value = id;
  document.getElementById("editName").value = name;
  document.getElementById("editSurname").value = surname;
  document.getElementById("editGrade").value = grade;
  document.getElementById("editDOB").value = dob;

  let modal = new bootstrap.Modal(document.getElementById("editStudentModal"));
  modal.show();
}
function showLockerConfirm(message, onYes) {
  document.getElementById("lockerConfirmMessage").textContent = message;
  
  const yesBtn = document.getElementById("lockerConfirmYes");
  const modalEl = document.getElementById("lockerConfirm");
  const modal = new bootstrap.Modal(modalEl);


  const newYesBtn = yesBtn.cloneNode(true);
  yesBtn.parentNode.replaceChild(newYesBtn, yesBtn);

  newYesBtn.addEventListener("click", () => {
    modal.hide();
    if (typeof onYes === "function") onYes();
  });

  modal.show();
}

// =======================
// Locker Alert Modal
// =======================
let lockerAlertModal; 

function showLockerAlert(type, message) {
  let header = document.querySelector(".locker-header");
  let titleEl = document.getElementById("lockerAlertTitle");
  let msgEl = document.getElementById("lockerAlertMessage");

  header.style.background = "#b71c1c";
  titleEl.textContent = "Locker Alert";

  if (type === "info") {
    header.style.background = "#1976d2";
    titleEl.textContent = "Information";
  } else if (type === "success") {
    header.style.background = "#388e3c";
    titleEl.textContent = "Success";
  } else if (type === "warning") {
    header.style.background = "#f57c00";
    titleEl.textContent = "Warning";
  } else if (type === "error") {
    header.style.background = "#d32f2f";
    titleEl.textContent = "Error";
  }

  msgEl.textContent = message;

  if (!lockerAlertModal) {
    lockerAlertModal = new bootstrap.Modal(document.getElementById("lockerAlert"));
  }
  lockerAlertModal.show();
}

// =======================
// Locker Loading Modal
// =======================
let lockerLoadingModal; 

function showLockerLoading(message = "Unlocking Locker…") {
  document.querySelector("#lockerLoading h5").textContent = message;

  if (!lockerLoadingModal) {
    lockerLoadingModal = new bootstrap.Modal(document.getElementById("lockerLoading"), {
      backdrop: 'static',
      keyboard: false
    });
  }
  lockerLoadingModal.show();
}

function hideLockerLoading() {
  if (lockerLoadingModal) {
    lockerLoadingModal.hide();
  }
}