
// =======================
// Parent Registration Handler
// =======================
document.addEventListener("DOMContentLoaded", () => {
  const parentForm = document.getElementById("parentRegisterForm");

  if (parentForm) {
    parentForm.addEventListener("submit", async (e) => {
      e.preventDefault();

      let formData = new FormData(parentForm);

      let regModalEl = document.getElementById("parentRegister");
      let regModal = bootstrap.Modal.getInstance(regModalEl);
      if (regModal) regModal.hide();

      showLockerLoading("Registering Parent...");

      try {
        let response = await fetch("./backend/register_parent.php", {
          method: "POST",
          body: formData
        });

        let result = await response.json();

        setTimeout(() => {
          hideLockerLoading();

          if (result.status === "success") {
            parentForm.reset();
            showLockerAlert("success", "Parent registered successfully!");
          } else {
            showLockerAlert("error", result.message || "Registration failed.");
          }
        }, 1000);

      } catch (err) {
        hideLockerLoading();
        showLockerAlert("error", "Registration failed: " + err.message);
      }
    });
  }
});

// =======================
// Parent Login Handler
// =======================
async function parentLogin() {
  let email = document.querySelector("#parent-login input[type='email']").value.trim();
  let password = document.getElementById("parentPassword").value.trim();

  if (email === "" || password === "") {
    showLockerAlert("warning", "Please enter both email and password.");
    return;
  }


  let loginCard = document.getElementById("parent-login");
  if (loginCard) loginCard.classList.add("d-none");


  showLockerLoading("Logging in...");

  try {
    let formData = new FormData();
    formData.append("Email", email);
    formData.append("Password", password);

    let response = await fetch("./backend/login_parent.php", {
      method: "POST",
      body: formData
    });

    let result = await response.json();

    setTimeout(() => {
      hideLockerLoading();

      if (result.status === "success") {
  showLockerAlert("success", result.message);

  setTimeout(() => {
    window.location.href = "parent_dashboard.php";
  }, 1500);
} else {
        showLockerAlert("error", result.message);

        if (loginCard) loginCard.classList.remove("d-none");
      }
    }, 1000);

  } catch (err) {
    hideLockerLoading();
    showLockerAlert("error", "Login failed: " + err.message);

    if (loginCard) loginCard.classList.remove("d-none");
  }
}

