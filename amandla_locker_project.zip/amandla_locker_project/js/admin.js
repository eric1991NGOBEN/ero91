document.addEventListener("DOMContentLoaded", () => {
  const dashboardTab = document.getElementById("dashboard-tab");
  dashboardTab.addEventListener("shown.bs.tab", loadDashboardCounts);
  loadDashboardCounts(); // also load on first visit to the page 
});

async function loadDashboardCounts() {
  try {
    const response = await fetch("./backend/get_dashboard_count.php");
    const data = await response.json();

    if (data.error) {
      console.error("Dashboard API error:", data.error);
      return;
    }

    updateCount("count-total-admins", data.totalAdmins);
    updateCount("count-active-waiting", data.activeWaiting ?? 0);
    updateCount("count-total-lockers", data.totalLockers);
    updateCount("count-booked-lockers", data.bookedLockers);
    updateCount("count-total-parents", data.totalParents);
    updateCount("count-total-students", data.totalStudents);
  } catch (err) {
    console.error("Failed to fetch dashboard counts:", err);
  }
}

function updateCount(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

// ===========================
// LOCKERS MANAGEMENT
// ===========================
let currentPage = 1;
let currentSearch = "";

document.addEventListener("DOMContentLoaded", () => {
  const lockersTab = document.getElementById("lockers-tab");
  lockersTab.addEventListener("shown.bs.tab", loadAdminLockers);


  document.addEventListener("submit", (e) => {
    if (e.target.id === "lockerSearchForm") {
      e.preventDefault();
      currentSearch = document.getElementById("lockerSearch").value;
      currentPage = 1;
      loadAdminLockers();
    }
  });

  // Save locker edit
  document.getElementById("saveLockerBtn").addEventListener("click", updateLocker);

  // Confirm delete
  document.getElementById("confirmDeleteLocker").addEventListener("click", deleteLocker);
});

async function loadAdminLockers(page = currentPage) {
  const container = document.getElementById("adminLockersContainer");
  container.innerHTML = `<div class="text-center text-muted py-4"><i class="bi bi-hourglass-split"></i> Loading lockers...</div>`;

  try {
    const response = await fetch(`./backend/get_lockers.php?page=${page}&search=${encodeURIComponent(currentSearch)}`);
    const data = await response.json();

    if (data.error) {
      container.innerHTML = `<div class="alert alert-danger">${data.error}</div>`;
      return;
    }

    const lockers = data.lockers || [];
    if (lockers.length === 0) {
      container.innerHTML = `<div class="alert alert-warning text-center">No lockers found.</div>`;
      return;
    }

    let html = `
      <form id="lockerSearchForm" class="mb-3 d-flex justify-content-end">
        <input id="lockerSearch" type="text" placeholder="Search lockers..." value="${currentSearch}" class="form-control w-auto me-2">
        <button class="btn btn-sm btn-outline-danger" type="submit"><i class="bi bi-search"></i></button>
      </form>
      <div class="table-responsive">
        <table class="table table-bordered align-middle">
          <thead class="table-danger">
            <tr>
              <th>ID</th>
              <th>Physical Location</th>
              <th>Grade</th>
              <th>Status</th>
              <th class="text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
    `;

    lockers.forEach(locker => {
      html += `
        <tr>
          <td>${locker.LockerID}</td>
          <td>${locker.PhysicalLocation}</td>
          <td>${locker.Grade}</td>
          <td>
            <span class="badge ${
              locker.Status === "Available"
                ? "bg-success"
                : locker.Status === "Booked"
                ? "bg-danger"
                : locker.Status === "Cancelled"
                ? "bg-secondary"
                : "bg-warning text-dark"
            }">${locker.Status}</span>
          </td>
          <td class="text-center">
            <button class="btn btn-sm btn-outline-primary me-1"
              data-bs-toggle="modal"
              data-bs-target="#editLockerModal"
              onclick="populateEditLocker(${locker.LockerID}, '${locker.PhysicalLocation}', '${locker.Grade}', '${locker.Status}')">
              <i class="bi bi-pencil-square"></i>
            </button>

            <button class="btn btn-sm btn-outline-danger me-1"
              data-bs-toggle="modal"
              data-bs-target="#deleteLockerModal"
              onclick="setDeleteLocker(${locker.LockerID})">
              <i class="bi bi-trash"></i>
            </button>

            <button class="btn btn-sm btn-outline-secondary"
              onclick="cancelLocker(${locker.LockerID})">
              <i class="bi bi-x-circle"></i> Cancel
            </button>
          </td>
        </tr>`;
    });

    html += `</tbody></table></div>`;

    // Pagination
    if (data.totalPages > 1) {
      html += `<nav class="mt-3"><ul class="pagination justify-content-center">`;
      for (let i = 1; i <= data.totalPages; i++) {
        html += `<li class="page-item ${i === data.currentPage ? "active" : ""}">
                  <a class="page-link" href="#" onclick="loadAdminLockers(${i}); return false;">${i}</a>
                 </li>`;
      }
      html += `</ul></nav>`;
    }

    container.innerHTML = html;
  } catch (err) {
    container.innerHTML = `<div class="alert alert-danger">Error loading lockers.</div>`;
  }
}


function populateEditLocker(id, location, grade, status) {
  document.getElementById("editLockerId").value = id;
  document.getElementById("editLockerLocation").value = location;
  document.getElementById("editLockerGrade").value = grade;
  document.getElementById("editLockerStatus").value = status;
}

function setDeleteLocker(id) {
  document.getElementById("deleteLockerId").value = id;
}


async function updateLocker() {
  const id = document.getElementById("editLockerId").value;
  const location = document.getElementById("editLockerLocation").value;
  const grade = document.getElementById("editLockerGrade").value;
  const status = document.getElementById("editLockerStatus").value;

  const formData = new FormData();
  formData.append("LockerID", id);
  formData.append("PhysicalLocation", location);
  formData.append("Grade", grade);
  formData.append("Status", status);

  const response = await fetch("./backend/update_locker.php", { method: "POST", body: formData });
  const result = await response.json();

  if (result.success) {
    bootstrap.Modal.getInstance(document.getElementById("editLockerModal")).hide();
    loadAdminLockers();
  } else {
    alert("Error updating locker: " + result.error);
  }
}


async function deleteLocker() {
  const id = document.getElementById("deleteLockerId").value;
  const formData = new FormData();
  formData.append("LockerID", id);

  const response = await fetch("./backend/delete_locker.php", { method: "POST", body: formData });
  const result = await response.json();

  if (result.success) {
    bootstrap.Modal.getInstance(document.getElementById("deleteLockerModal")).hide();
    loadAdminLockers();
  } else {
    alert("Error deleting locker: " + result.error);
  }
}


async function cancelLocker(id) {
  if (!confirm("Are you sure you want to mark this locker as Cancelled?")) return;

  const formData = new FormData();
  formData.append("LockerID", id);
  formData.append("PhysicalLocation", ""); // not updating location
  formData.append("Grade", "8"); // default reverting to if breaks
  formData.append("Status", "Cancelled");

  const response = await fetch("./backend/update_locker.php", { method: "POST", body: formData });
  const result = await response.json();

  if (result.success) {
    loadAdminLockers();
  } else {
    alert("Error cancelling locker: " + result.error);
  }
}
// ===========================
// ADD NEW LOCKER
// ===========================
document.addEventListener("DOMContentLoaded", () => {
  const addBtn = document.getElementById("saveNewLockerBtn");
  if (addBtn) addBtn.addEventListener("click", addNewLocker);
});

async function addNewLocker() {
  const location = document.getElementById("newLockerLocation").value.trim();
  const grade = document.getElementById("newLockerGrade").value;

  if (!location || !grade) {
    alert("Please fill in all fields.");
    return;
  }

  const formData = new FormData();
  formData.append("PhysicalLocation", location);
  formData.append("Grade", grade);

  const response = await fetch("./backend/add_locker.php", { method: "POST", body: formData });
  const result = await response.json();

  if (result.success) {
    bootstrap.Modal.getInstance(document.getElementById("addLockerModal")).hide();
    loadAdminLockers();
  } else {
    alert("Error adding locker: " + result.error);
  }
}


// ===========================
// STUDENTS MANAGEMENT
// ===========================
let currentStudentPage = 1;
let currentStudentSearch = "";

document.addEventListener("DOMContentLoaded", () => {
  const studentsTab = document.getElementById("students-tab");
  studentsTab.addEventListener("shown.bs.tab", loadAdminStudents);

  document.addEventListener("submit", (e) => {
    if (e.target.id === "studentSearchForm") {
      e.preventDefault();
      currentStudentSearch = document.getElementById("studentSearch").value.trim();
      currentStudentPage = 1;
      loadAdminStudents();
    }
  });

  const saveBtn = document.getElementById("saveStudentBtn");
  if (saveBtn) saveBtn.addEventListener("click", updateStudent);

  const delBtn = document.getElementById("confirmDeleteStudent");
  if (delBtn) delBtn.addEventListener("click", deleteStudent);
});

async function loadAdminStudents(page = currentStudentPage) {
  const container = document.getElementById("adminStudentsContainer");
  container.innerHTML = `<div class="text-center text-muted py-4"><i class="bi bi-hourglass-split"></i> Loading students...</div>`;

  try {
    const response = await fetch(`./backend/get_students_admin.php?page=${page}&search=${encodeURIComponent(currentStudentSearch)}`);
    const data = await response.json();

    if (data.error) {
      container.innerHTML = `<div class="alert alert-danger">${data.error}</div>`;
      return;
    }

    const students = data.students || [];
    if (students.length === 0) {
      container.innerHTML = `<div class="alert alert-warning text-center">No students found.</div>`;
      return;
    }

    // HTML Table
    let html = `
      <form id="studentSearchForm" class="mb-3 d-flex justify-content-end">
        <input id="studentSearch" type="text" placeholder="Search students..." value="${currentStudentSearch}" class="form-control w-auto me-2">
        <button class="btn btn-sm btn-outline-danger" type="submit"><i class="bi bi-search"></i></button>
      </form>
      <div class="table-responsive">
        <table class="table table-bordered align-middle">
          <thead class="table-danger">
            <tr>
              <th>ID</th>
              <th>Parent</th>
              <th>Name</th>
              <th>Surname</th>
              <th>Grade</th>
              <th>Date of Birth</th>
              <th class="text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
    `;

    students.forEach(stu => {
      const safeName = stu.Name.replace(/'/g, "\\'").replace(/"/g, "&quot;");
      const safeSurname = stu.Surname.replace(/'/g, "\\'").replace(/"/g, "&quot;");
      const safeGrade = String(stu.Grade).replace(/'/g, "\\'");
      const safeDob = stu.DateOfBirth || "";
      const parentName = stu.ParentDisplay || `Parent ID: ${stu.ParentID}`;

      html += `
        <tr>
          <td>${stu.StudentID}</td>
          <td>${parentName}</td>
          <td>${safeName}</td>
          <td>${safeSurname}</td>
          <td>${safeGrade}</td>
          <td>${safeDob}</td>
          <td class="text-center">
            <button class="btn btn-sm btn-outline-primary me-2" 
              data-bs-toggle="modal" 
              data-bs-target="#editStudentModal"
              onclick="populateEditStudent(${stu.StudentID}, ${stu.ParentID}, '${safeName}', '${safeSurname}', '${safeGrade}', '${safeDob}')">
              <i class="bi bi-pencil-square"></i>
            </button>
            <button class="btn btn-sm btn-outline-danger" 
              data-bs-toggle="modal" 
              data-bs-target="#deleteStudentModal"
              onclick="setDeleteStudent(${stu.StudentID})">
              <i class="bi bi-trash"></i>
            </button>
          </td>
        </tr>
      `;
    });

    html += `</tbody></table></div>`;


    if (data.totalPages > 1) {
      html += `<nav class="mt-3"><ul class="pagination justify-content-center">`;
      for (let i = 1; i <= data.totalPages; i++) {
        html += `
          <li class="page-item ${i === data.currentPage ? "active" : ""}">
            <a class="page-link" href="#" onclick="loadAdminStudents(${i}); return false;">${i}</a>
          </li>`;
      }
      html += `</ul></nav>`;
    }

    container.innerHTML = html;
  } catch (err) {
    console.error(err);
    container.innerHTML = `<div class="alert alert-danger">Error loading students. Please check your backend or JSON output.</div>`;
  }
}

// ======= MODAL LOGIC =======
function populateEditStudent(id, parentId, name, surname, grade, dob) {
  document.getElementById("editStudentId").value = id;
  document.getElementById("editStudentParentId").value = parentId;
  document.getElementById("editStudentName").value = name;
  document.getElementById("editStudentSurname").value = surname;
  document.getElementById("editStudentGrade").value = grade;
  document.getElementById("editStudentDob").value = dob;
}

function setDeleteStudent(id) {
  document.getElementById("deleteStudentId").value = id;
}

async function updateStudent() {
  const formData = new FormData();
  formData.append("StudentID", document.getElementById("editStudentId").value);
  formData.append("ParentID", document.getElementById("editStudentParentId").value);
  formData.append("Name", document.getElementById("editStudentName").value);
  formData.append("Surname", document.getElementById("editStudentSurname").value);
  formData.append("Grade", document.getElementById("editStudentGrade").value);
  formData.append("DateOfBirth", document.getElementById("editStudentDob").value);

  const response = await fetch("./backend/update_student.php", { method: "POST", body: formData });
  const result = await response.json();

  if (result.success) {
    bootstrap.Modal.getInstance(document.getElementById("editStudentModal")).hide();
    loadAdminStudents();
  } else {
    alert("Error updating student: " + result.error);
  }
}

async function deleteStudent() {
  const id = document.getElementById("deleteStudentId").value;
  const formData = new FormData();
  formData.append("StudentID", id);

  const response = await fetch("./backend/delete_student_admin.php", { method: "POST", body: formData });
  const result = await response.json();

  if (result.success) {
    bootstrap.Modal.getInstance(document.getElementById("deleteStudentModal")).hide();
    loadAdminStudents();
  } else {
    alert("Error deleting student: " + result.error);
  }
}
document.addEventListener("DOMContentLoaded", () => {
  const addStudentBtn = document.getElementById("saveNewStudentBtn");
  if (addStudentBtn) addStudentBtn.addEventListener("click", addNewStudent);
});

async function addNewStudent() {
  const formData = new FormData();
  formData.append("ParentID", document.getElementById("newStudentParentId").value);
  formData.append("Name", document.getElementById("newStudentName").value);
  formData.append("Surname", document.getElementById("newStudentSurname").value);
  formData.append("Grade", document.getElementById("newStudentGrade").value);
  formData.append("DateOfBirth", document.getElementById("newStudentDob").value);

  try {
    const response = await fetch("./backend/add_student_admin.php", {
      method: "POST",
      body: formData
    });
    const result = await response.json();

    if (result.success) {
      bootstrap.Modal.getInstance(document.getElementById("addStudentModal")).hide();
      loadAdminStudents();
    } else {
      alert("Error: " + result.error);
    }
  } catch (err) {
    alert("Failed to add student. Check console for details.");
    console.error(err);
  }
}
// ===========================
// LOAD PARENTS INTO DROPDOWN
// ===========================
document.addEventListener("DOMContentLoaded", () => {
  const addStudentModal = document.getElementById("addStudentModal");

  if (addStudentModal) {
    // When modal opens, reload parents list
    addStudentModal.addEventListener("show.bs.modal", async () => {
      await loadParentDropdown("newStudentParentId");
      document.getElementById("addStudentForm").reset();
    });
  }
});

async function loadParentDropdown(selectId) {
  const dropdown = document.getElementById(selectId);
  dropdown.innerHTML = `<option>Loading parents...</option>`;

  try {
    const response = await fetch("./backend/get_parent_list.php");
    const data = await response.json();

    if (data.error) {
      dropdown.innerHTML = `<option value="">Error loading parents</option>`;
      return;
    }

    const parents = data.parents || [];
    if (parents.length === 0) {
      dropdown.innerHTML = `<option value="">No parents found</option>`;
      return;
    }

    dropdown.innerHTML = `<option value="">Select Parent</option>`;
    parents.forEach(p => {
      const option = document.createElement("option");
      option.value = p.ParentID;
      option.textContent = p.DisplayName;
      dropdown.appendChild(option);
    });
  } catch (err) {
    console.error("Parent dropdown load error:", err);
    dropdown.innerHTML = `<option value="">Error loading parents</option>`;
  }
}
// ===========================
// PARENTS MANAGEMENT
// ===========================
let currentParentPage = 1;
let currentParentSearch = "";

document.addEventListener("DOMContentLoaded", () => {
  const parentsTab = document.getElementById("parents-tab");
  if (parentsTab) parentsTab.addEventListener("shown.bs.tab", loadAdminParents);

  // Search form event listener (delegated)
  document.addEventListener("submit", (e) => {
    if (e.target.id === "parentSearchForm") {
      e.preventDefault();
      currentParentSearch = document.getElementById("parentSearch").value.trim();
      currentParentPage = 1;
      loadAdminParents();
    }
  });

  const saveBtn = document.getElementById("saveParentBtn");
  if (saveBtn) saveBtn.addEventListener("click", updateParent);

  const delBtn = document.getElementById("confirmDeleteParent");
  if (delBtn) delBtn.addEventListener("click", deleteParent);
});

async function loadAdminParents(page = currentParentPage) {
  const container = document.getElementById("adminParentsContainer");
  container.innerHTML = `<div class="text-center text-muted py-4"><i class="bi bi-hourglass-split"></i> Loading parents...</div>`;

  try {
    const response = await fetch(`./backend/get_parents_admin.php?page=${page}&search=${encodeURIComponent(currentParentSearch)}`);
    const data = await response.json();

    if (data.error) {
      container.innerHTML = `<div class="alert alert-danger">${data.error}</div>`;
      return;
    }

    const parents = data.parents || [];
    if (parents.length === 0) {
      container.innerHTML = `<div class="alert alert-warning text-center">No parents found.</div>`;
      return;
    }


    let html = `
      <form id="parentSearchForm" class="mb-3 d-flex justify-content-end">
        <input id="parentSearch" type="text" placeholder="Search parents..." value="${currentParentSearch}" class="form-control w-auto me-2">
        <button class="btn btn-sm btn-outline-danger" type="submit"><i class="bi bi-search"></i></button>
      </form>
      <div class="table-responsive">
        <table class="table table-bordered align-middle">
          <thead class="table-danger">
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Cellphone</th>
              <th>City</th>
              <th class="text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
    `;

    parents.forEach((p) => {
      const safeName = p.Name.replace(/'/g, "\\'");
      const safeSurname = p.Surname.replace(/'/g, "\\'");
      const safeEmail = p.Email.replace(/'/g, "\\'");
      const safeCell = p.Cellphone.replace(/'/g, "\\'");
      const safeCity = p.City.replace(/'/g, "\\'");

      html += `
        <tr>
          <td>${p.ParentID}</td>
          <td>${p.Name} ${p.Surname}</td>
          <td>${p.Email}</td>
          <td>${p.Cellphone}</td>
          <td>${p.City}</td>
          <td class="text-center">
            <button class="btn btn-sm btn-outline-primary me-2" data-bs-toggle="modal" data-bs-target="#editParentModal"
              onclick="populateEditParent(${p.ParentID}, '${safeName}', '${safeSurname}', '${safeEmail}', '${safeCell}', '${safeCity}')">
              <i class="bi bi-pencil-square"></i>
            </button>
            <button class="btn btn-sm btn-outline-info me-2"
              onclick="viewLinkedStudents(${p.ParentID})" title="View Linked Students">
              <i class="bi bi-people"></i>
            </button>
            <button class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#deleteParentModal"
              onclick="setDeleteParent(${p.ParentID})">
              <i class="bi bi-trash"></i>
            </button>
          </td>
        </tr>`;
    });

    html += `</tbody></table></div>`;

    if (data.totalPages > 1) {
      html += `<nav class="mt-3"><ul class="pagination justify-content-center">`;
      for (let i = 1; i <= data.totalPages; i++) {
        html += `<li class="page-item ${i === data.currentPage ? "active" : ""}">
                  <a class="page-link" href="#" onclick="loadAdminParents(${i}); return false;">${i}</a>
                 </li>`;
      }
      html += `</ul></nav>`;
    }

    container.innerHTML = html;
  } catch (err) {
    console.error("❌ Error loading parents:", err);
    container.innerHTML = `<div class="alert alert-danger">Error loading parents data.</div>`;
  }
}


function populateEditParent(id, name, surname, email, cell, city) {
  document.getElementById("editParentId").value = id;
  document.getElementById("editParentName").value = name;
  document.getElementById("editParentSurname").value = surname;
  document.getElementById("editParentEmail").value = email;
  document.getElementById("editParentCell").value = cell;
  document.getElementById("editParentCity").value = city;
}

function setDeleteParent(id) {
  document.getElementById("deleteParentId").value = id;
}

async function updateParent() {
  const formData = new FormData();
  formData.append("ParentID", document.getElementById("editParentId").value);
  formData.append("Name", document.getElementById("editParentName").value);
  formData.append("Surname", document.getElementById("editParentSurname").value);
  formData.append("Email", document.getElementById("editParentEmail").value);
  formData.append("Cellphone", document.getElementById("editParentCell").value);
  formData.append("City", document.getElementById("editParentCity").value);

  try {
    const response = await fetch("./backend/update_parent.php", { method: "POST", body: formData });
    const result = await response.json();

    if (result.success) {
      bootstrap.Modal.getInstance(document.getElementById("editParentModal")).hide();
      loadAdminParents();
    } else {
      alert("Error updating parent: " + (result.error || "Unknown error"));
    }
  } catch (err) {
    alert("Failed to update parent. Please check connection or backend logs.");
  }
}

async function deleteParent() {
  const id = document.getElementById("deleteParentId").value;
  const formData = new FormData();
  formData.append("ParentID", id);

  try {
    const response = await fetch("./backend/delete_parent_admin.php", { method: "POST", body: formData });
    const result = await response.json();

    if (result.success) {
      bootstrap.Modal.getInstance(document.getElementById("deleteParentModal")).hide();
      loadAdminParents();
    } else {
      alert("Error deleting parent: " + (result.error || "Unknown error"));
    }
  } catch (err) {
    alert("Failed to delete parent. Please check connection or backend logs.");
  }
}

async function viewLinkedStudents(parentId) {
  const container = document.getElementById("linkedStudentsContainer");
  container.innerHTML = `<p class="text-muted text-center">Loading students...</p>`;

  const modalEl = document.getElementById("viewLinkedStudentsModal");
  const modal = new bootstrap.Modal(modalEl);
  modal.show();

  try {
    const res = await fetch(`./backend/get_students_by_parent.php?parentId=${parentId}`);
    const data = await res.json();

    if (data.error) {
      container.innerHTML = `<div class="alert alert-danger">${data.error}</div>`;
      return;
    }

    const students = data.students || [];
    if (students.length === 0) {
      container.innerHTML = `<div class="alert alert-warning text-center">No students linked to this parent.</div>`;
      return;
    }

    let html = `<table class="table table-bordered align-middle">
                  <thead class="table-danger">
                    <tr><th>ID</th><th>Name</th><th>Surname</th><th>Grade</th><th>Date of Birth</th></tr>
                  </thead><tbody>`;
    students.forEach((s) => {
      html += `<tr>
                <td>${s.StudentID}</td>
                <td>${s.Name}</td>
                <td>${s.Surname}</td>
                <td>${s.Grade}</td>
                <td>${s.DateOfBirth}</td>
              </tr>`;
    });
    html += `</tbody></table>`;
    container.innerHTML = html;
  } catch (err) {
    console.error("❌ Failed to load students:", err);
    container.innerHTML = `<div class="alert alert-danger text-center">Failed to load linked students.</div>`;
  }
}
// ===========================
// REPORTING DASHBOARD
// ===========================
document.addEventListener("DOMContentLoaded", () => {
  const reportsTab = document.getElementById("reports-tab");
  if (reportsTab) reportsTab.addEventListener("shown.bs.tab", loadReports);
});

async function loadReports() {
  const container = document.getElementById("reportsContainer");
  container.innerHTML = `<i class="bi bi-hourglass-split"></i> Generating reports...`;

  try {
    const res = await fetch("./backend/get_reports_admin.php");
    const data = await res.json();

    const s = data.summary;
    let html = `
      <div class="row g-3 text-center">
        <div class="col-md-3"><div class="card border-success shadow-sm"><div class="card-body">
          <h6>Total Lockers</h6><h3>${s.totalLockers}</h3>
        </div></div></div>

        <div class="col-md-3"><div class="card border-primary shadow-sm"><div class="card-body">
          <h6>Booked Lockers</h6><h3>${s.bookedLockers}</h3>
        </div></div></div>

        <div class="col-md-3"><div class="card border-warning shadow-sm"><div class="card-body">
          <h6>Pending Payments</h6><h3>${s.pending}</h3>
        </div></div></div>

        <div class="col-md-3"><div class="card border-danger shadow-sm"><div class="card-body">
          <h6>Cancelled</h6><h3>${s.cancelled}</h3>
        </div></div></div>
      </div>

      <div class="mt-4 p-3 bg-light rounded shadow-sm text-start">
        <h5 class="text-danger mb-3"><i class="bi bi-cash-stack"></i> Financial Summary</h5>
        <p><strong>Revenue (R150 × booked):</strong> <h3><span class="fw-bold text-success">R${s.revenue.toLocaleString()}</span></p></h3>
      </div>
    `;

    // Bookings per grade
    html += `<h6 class="mt-4 text-danger">Bookings by Grade</h6>
             <table class="table table-bordered"><thead><tr><th>Grade</th><th>Total Bookings</th></tr></thead><tbody>`;
    data.bookingsByGrade.forEach(g => {
      html += `<tr><td>${g.Grade}</td><td>${g.total}</td></tr>`;
    });
    html += `</tbody></table>`;

    // Monthly trend
    html += `<h6 class="mt-4 text-danger">Monthly Booking Trend</h6>
             <table class="table table-bordered"><thead><tr><th>Month</th><th>Bookings</th></tr></thead><tbody>`;
    data.monthlyTrend.forEach(m => {
      html += `<tr><td>${m.month}</td><td>${m.total}</td></tr>`;
    });
    html += `</tbody></table>`;

    container.innerHTML = html;
  } catch (err) {
    container.innerHTML = `<div class="alert alert-danger">Error loading reports.</div>`;
  }
}
// ===========================
// EXPORT REPORTS AS XML
// ===========================
document.addEventListener("DOMContentLoaded", () => {
  const exportBtn = document.getElementById("exportXMLBtn");
  if (exportBtn) {
    exportBtn.addEventListener("click", () => {
      window.open("./backend/export_reports_xml.php", "_blank");
    });
  }
});
// ===========================
// LOCKER BOOKINGS MANAGEMENT
// ===========================
document.addEventListener("DOMContentLoaded", () => {
  const bookingsTab = document.getElementById("bookings-tab");
  if (bookingsTab) {
    bookingsTab.addEventListener("shown.bs.tab", loadAdminBookings);
  }
});

async function loadAdminBookings() {
  const container = document.getElementById("adminBookingsContainer");
  container.innerHTML = `<div class="text-center text-muted py-4"><i class="bi bi-hourglass-split"></i> Loading bookings...</div>`;

  try {
    const response = await fetch("./backend/get_locker_bookings_admin.php");
    const data = await response.json();

    const bookings = data.bookings || [];
    if (bookings.length === 0) {
      container.innerHTML = `<div class="alert alert-warning text-center">No locker bookings found.</div>`;
      return;
    }

    let html = `
      <div class="table-responsive">
        <table class="table table-bordered align-middle">
          <thead class="table-danger">
            <tr>
              <th>Booking ID</th>
              <th>Student</th>
              <th>Grade</th>
              <th>Locker</th>
              <th>Parent</th>
              <th>Date</th>
              <th>Status</th>
              <th class="text-center">Action</th>
            </tr>
          </thead>
          <tbody>
    `;

    bookings.forEach(b => {
      html += `
        <tr>
          <td>${b.BookingID}</td>
          <td>${b.StudentName} ${b.StudentSurname}</td>
          <td>${b.StudentGrade}</td>
          <td>${b.LockerLocation}</td>
          <td>${b.ParentName} ${b.ParentSurname}</td>
          <td>${b.BookingDate}</td>
          <td>
            <span class="badge ${
              b.Status === "Booked"
                ? "bg-success"
                : b.Status === "Pending Payment"
                ? "bg-warning text-dark"
                : "bg-secondary"
            }">${b.Status}</span>
          </td>
          <td class="text-center">
            <div class="btn-group">
              <button class="btn btn-sm btn-outline-success" onclick="updateBookingStatus(${b.BookingID}, 'Booked')">
                <i class="bi bi-check-circle"></i>
              </button>
              <button class="btn btn-sm btn-outline-warning" onclick="updateBookingStatus(${b.BookingID}, 'Pending Payment')">
                <i class="bi bi-hourglass-split"></i>
              </button>
              <button class="btn btn-sm btn-outline-secondary" onclick="updateBookingStatus(${b.BookingID}, 'Cancelled')">
                <i class="bi bi-x-circle"></i>
              </button>
            </div>
          </td>
        </tr>
      `;
    });

    html += `</tbody></table></div>`;
    container.innerHTML = html;
  } catch (err) {
    container.innerHTML = `<div class="alert alert-danger text-center">Failed to load bookings.</div>`;
  }
}

async function updateBookingStatus(bookingID, newStatus) {
  const formData = new FormData();
  formData.append("BookingID", bookingID);
  formData.append("Status", newStatus);

  const response = await fetch("./backend/update_booking_status.php", {
    method: "POST",
    body: formData,
  });
  const result = await response.json();

  if (result.success) {
    loadAdminBookings();
  } else {
    alert("Error updating booking: " + result.error);
  }
}
// ===========================
// WAITING LIST MANAGEMENT
// ===========================
document.addEventListener("DOMContentLoaded", () => {
  const tab = document.getElementById("waitinglist-tab");
  if (tab) tab.addEventListener("shown.bs.tab", loadAdminWaitingList);
});

async function loadAdminWaitingList() {
  const container = document.getElementById("adminWaitingListContainer");
  container.innerHTML = `<div class="text-center text-muted py-4"><i class="bi bi-hourglass-split"></i> Loading waiting list...</div>`;

  try {
    const res = await fetch("./backend/get_waiting_list_admin.php");
    const data = await res.json();
    const list = data.waitinglist || [];

    if (list.length === 0) {
      container.innerHTML = `<div class="alert alert-warning">No active waiting list entries found.</div>`;
      return;
    }

    let html = `
      <div class="table-responsive">
        <table class="table table-bordered align-middle">
          <thead class="table-danger">
            <tr>
              <th>ID</th>
              <th>Student</th>
              <th>Parent</th>
              <th>Grade</th>
              <th>Status</th>
              <th>Requested On</th>
              <th class="text-center">Action</th>
            </tr>
          </thead>
          <tbody>
    `;

    list.forEach(w => {
      html += `
        <tr>
          <td>${w.WaitingID}</td>
          <td>${w.StudentName} ${w.StudentSurname}</td>
          <td>${w.ParentName} ${w.ParentSurname}</td>
          <td>${w.Grade}</td>
          <td><span class="badge ${w.Status === "Active" ? "bg-warning text-dark" : "bg-secondary"}">${w.Status}</span></td>
          <td>${w.CreatedAt}</td>
          <td class="text-center">
            <button class="btn btn-sm btn-outline-success" onclick="assignWaitingLocker(${w.WaitingID})">
              <i class="bi bi-box-arrow-in-right"></i> Assign Locker
            </button>
          </td>
        </tr>
      `;
    });

    html += `</tbody></table></div>`;
    container.innerHTML = html;
  } catch {
    container.innerHTML = `<div class="alert alert-danger">Error loading waiting list.</div>`;
  }
}

async function assignWaitingLocker(waitingID) {
  const formData = new FormData();
  formData.append("WaitingID", waitingID);

  const res = await fetch("./backend/assign_waiting_locker.php", {
    method: "POST",
    body: formData,
  });
  const result = await res.json();

  if (result.success) {
    alert("Locker assigned successfully!");
    loadAdminWaitingList();
  } else {
    alert("Error: " + result.error);
  }
}
