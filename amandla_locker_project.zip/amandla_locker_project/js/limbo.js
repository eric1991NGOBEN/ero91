// =======================
// Portal Switching
// =======================
function showLogin(type) {
  document.getElementById('portal-selection').classList.add('d-none');
  if (type === 'parent') {
    document.getElementById('parent-login').classList.remove('d-none');
  } else {
    document.getElementById('admin-login').classList.remove('d-none');
  }
}

// =======================
// Toggle Password
// =======================
function togglePassword(inputId) {
  const input = document.getElementById(inputId);
  input.type = input.type === "password" ? "text" : "password";
}

// =======================
// Locker Alert Modal
// =======================
let lockerAlertModal; 

function showLockerAlert(type, message) {
  let header = document.querySelector(".locker-header");
  let titleEl = document.getElementById("lockerAlertTitle");
  let msgEl = document.getElementById("lockerAlertMessage");

  // Default styling
  header.style.background = "#b71c1c";
  titleEl.textContent = "Locker Alert";

  // Type specific
  if (type === "info") {
    header.style.background = "#1976d2";
    titleEl.textContent = "Information";
  } else if (type === "success") {
    header.style.background = "#388e3c";
    titleEl.textContent = "Success";
  } else if (type === "warning") {
    header.style.background = "#f57c00";
    titleEl.textContent = "Warning";
  } else if (type === "error") {
    header.style.background = "#d32f2f";
    titleEl.textContent = "Error";
  }

  msgEl.textContent = message;


  if (!lockerAlertModal) {
    lockerAlertModal = new bootstrap.Modal(document.getElementById("lockerAlert"));
  }
  lockerAlertModal.show();
}

// =======================
// Locker Loading Modal
// =======================
let lockerLoadingModal; 

function showLockerLoading(message = "Unlocking Locker…") {
  document.querySelector("#lockerLoading h5").textContent = message;

  if (!lockerLoadingModal) {
    lockerLoadingModal = new bootstrap.Modal(document.getElementById("lockerLoading"), {
      backdrop: 'static',
      keyboard: false
    });
  }
  lockerLoadingModal.show();
}

function hideLockerLoading() {
  if (lockerLoadingModal) {
    lockerLoadingModal.hide();
  }
}

async function adminLogin() {
  const email = document.querySelector('#admin-login input[type="email"]').value.trim();
  const password = document.querySelector('#adminPassword').value.trim();

  if (!email || !password) {
    showLockerAlert('warning', 'Please fill in both fields.');
    return;
  }

  showLockerLoading("Verifying credentials...");

  try {
    const formData = new FormData();
    formData.append("email", email);
    formData.append("password", password);

    const response = await fetch("./backend/admin_login.php", {
      method: "POST",
      body: formData
    });

    const result = await response.json();
    hideLockerLoading();

    if (result.status === "success") {
      showLockerAlert("success", "Welcome back, admin!");
      setTimeout(() => {
        window.location.href = "admin_dashboard.php";
      }, 1000);
    } else {
      showLockerAlert("error", result.message);
    }
  } catch (err) {
    hideLockerLoading();
    showLockerAlert("error", "Error: " + err.message);
  }
}
