document.addEventListener("DOMContentLoaded", () => {
  // Super Super fix only load when user switches to the Locker Bookings tab
  const lockersTab = document.getElementById("lockers-tab");

  lockersTab.addEventListener("shown.bs.tab", () => {
    loadLockerBookings();
  });
});

// ===========================
// LOAD LOCKER BOOKINGS (Fixed)
// ===========================
async function loadLockerBookings() {


  try {
    const response = await fetch("./backend/get_locker_bookings.php");
    const data = await response.json();


    const container = document.getElementById("lockerBookingsWrapper");
    container.innerHTML = "";

    if (!data || data.length === 0) {
      container.innerHTML = `<div class="alert alert-warning text-center">No students found or no bookings yet.</div>`;
      return;
    }

    // Build table markup
    let tableHTML = `
      <table class="table table-bordered text-center align-middle">
        <thead class="table-danger">
          <tr>
            <th>Student</th>
            <th>Grade</th>
            <th>Locker</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
    `;

    data.forEach(row => {
      const bookingID = row.BookingID || null;
      const bookingStatus = row.BookingStatus || "";
      const lockerLocation = row.LockerLocation || "-";

      let statusBadge = `<span class="badge bg-light text-dark">None</span>`;
      let actionBtn = `
        <button class="btn btn-outline-danger btn-sm"
          onclick="openLockerApplyModal(${row.StudentID}, '${row.Name}', '${row.Surname}', '${row.Grade}')">
          <i class="bi bi-plus-circle"></i> Apply
        </button>`;

      if (bookingStatus) {
        let color = "light";
        switch (bookingStatus) {
          case "Booked":
            color = "success";
            break;
          case "Pending Payment":
            color = "warning";
            break;
          case "Cancelled":
            color = "secondary";
            break;
        }
        statusBadge = `<span class="badge bg-${color}">${bookingStatus}</span>`;


        if (bookingStatus === "Booked") {
          actionBtn = `<button class="btn btn-outline-secondary btn-sm" disabled><i class="bi bi-lock-fill"></i> Booked</button>`;
        } else if (bookingStatus === "Pending Payment") {
          actionBtn = `
            <button class="btn btn-outline-success btn-sm"
              onclick="openPaymentModal(${row.BookingID}, '${row.Name} ${row.Surname}')">
              <i class="bi bi-credit-card"></i> Pay Now
            </button>`;
        } else {
          actionBtn = `<button class="btn btn-outline-secondary btn-sm" disabled><i class="bi bi-dash-circle"></i></button>`;
        }
      }

      tableHTML += `
        <tr>
          <td>${row.Name} ${row.Surname}</td>
          <td>${row.Grade}</td>
          <td>${lockerLocation}</td>
          <td>${statusBadge}</td>
          <td>${actionBtn}</td>
        </tr>`;
    });

    tableHTML += "</tbody></table>";
    container.innerHTML = tableHTML;

  } catch (err) {
    clearTimeout(safetyTimeout);
    hideLockerLoading();
    showLockerAlert("error", "Error loading locker bookings: " + err.message);
  }
}

// ===========================
// OPEN APPLY LOCKER MODAL
// ===========================
async function openLockerApplyModal(studentID, name, surname, grade) {
  const select = document.getElementById("availableLockerSelect");
  const studentNameEl = document.getElementById("applyLockerStudentName");
  const studentGradeEl = document.getElementById("applyLockerStudentGrade");
  const hiddenStudentId = document.getElementById("applyLockerStudentID");


  select.innerHTML = `<option>Loading lockers...</option>`;
  studentNameEl.textContent = `${name} ${surname}`;
  studentGradeEl.textContent = grade;
  hiddenStudentId.value = studentID;

  const modal = new bootstrap.Modal(document.getElementById("applyLockerModal"));
  modal.show();

  try {
    const response = await fetch(`./backend/get_available_lockers.php?grade=${grade}`);
    const lockers = await response.json();

    select.innerHTML = ""; 

    if (!lockers || lockers.length === 0) {
      //  No lockers available: auto add to waiting list 
      select.innerHTML = `<option value="none">No lockers available for grade ${grade}</option>`;

      // Optionally auto-register the student in waiting list
      const formData = new FormData();
      formData.append("StudentID", studentID);
      formData.append("Grade", grade);

      try {
        const waitRes = await fetch("./backend/add_to_waitinglist.php", {
          method: "POST",
          body: formData,
        });
        const waitData = await waitRes.json();

        if (waitData.success) {
          showLockerAlert(
            "info",
            `No lockers available for Grade ${grade}. ${name} has been added to the waiting list.`
          );
        } else {
          showLockerAlert("warning", `Could not add to waiting list: ${waitData.error || "Unknown error"}`);
        }
      } catch (err) {
        showLockerAlert("error", "Failed to contact waiting list service: " + err.message);
      }

      return; 
    }


    lockers.forEach(lock => {
      select.innerHTML += `<option value="${lock.LockerID}">${lock.PhysicalLocation}</option>`;
    });
  } catch (err) {
    showLockerAlert("error", "Error loading lockers: " + err.message);
  }
}


// ===========================
// APPLY LOCKER CONFIRMATION
// ===========================
async function submitLockerBooking() {
  let lockerID = document.getElementById("availableLockerSelect").value;
  let studentID = document.getElementById("applyLockerStudentID").value;

  if (!lockerID) {
    showLockerAlert("warning", "Please select a locker first.");
    return;
  }


  try {
    let formData = new FormData();
    formData.append("LockerID", lockerID);
    formData.append("StudentID", studentID);

    let response = await fetch("./backend/book_locker.php", {
      method: "POST",
      body: formData
    });
    let result = await response.json();


    if (result.status === "success") {
      bootstrap.Modal.getInstance(document.getElementById("applyLockerModal")).hide();
      showLockerAlert("success", result.message);
      loadLockerBookings();
    } else {
      showLockerAlert("error", result.message);
    }
  } catch (err) {
    hideLockerLoading();
    showLockerAlert("error", "Error booking locker: " + err.message);
  }
}

document.addEventListener("click", (e) => {
  if (e.target.id === "refreshLockersBtn") loadLockerBookings();
});


document.addEventListener("input", (e) => {
  if (e.target.id === "lockerSearch") {
    const query = e.target.value.toLowerCase();
    document.querySelectorAll("#lockerBookingsWrapper tbody tr").forEach(row => {
      row.style.display = row.innerText.toLowerCase().includes(query) ? "" : "none";
    });
  }
});
// ===========================
// OPEN PAYMENT MODAL
// ===========================
function openPaymentModal(bookingID, studentName) {
  const idField = document.getElementById("paymentBookingID");
  const infoField = document.getElementById("paymentStudentInfo");

  if (idField && infoField) {
    idField.value = bookingID;
    infoField.textContent = `Student: ${studentName}`;
  }


  ["paymentCardType", "paymentCardNumber", "paymentExpiry", "paymentCVV"].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = "";
  });

  const modal = new bootstrap.Modal(document.getElementById("paymentModal"));
  modal.show();
}

// ===========================
// CONFIRM PAYMENT
// ===========================
document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("confirmPaymentBtn");
  if (btn) btn.addEventListener("click", confirmPayment);
});

async function confirmPayment() {
  const bookingID = document.getElementById("paymentBookingID").value.trim();
  const cardType = document.getElementById("paymentCardType").value.trim();
  const cardNumber = document.getElementById("paymentCardNumber").value.trim();
  const expiry = document.getElementById("paymentExpiry").value.trim();
  const cvv = document.getElementById("paymentCVV").value.trim();
  const confirmBtn = document.getElementById("confirmPaymentBtn");

  if (!cardType || !cardNumber || !expiry || !cvv) {
    showLockerAlert("warning", "Please fill in all card details before paying.");
    return;
  }


  const modalEl = document.getElementById("paymentModal");
  const modalInstance = bootstrap.Modal.getInstance(modalEl);
  if (modalInstance) modalInstance.hide();

  confirmBtn.disabled = true;
  confirmBtn.innerHTML = `<i class="bi bi-hourglass-split"></i> Processing...`;
  showLockerLoading();

  try {

    await new Promise(res => setTimeout(res, 1000));

    const formData = new FormData();
    formData.append("BookingID", bookingID);

    const response = await fetch("./backend/confirm_payment.php", {
      method: "POST",
      body: formData
    });

    let result;
    try {
      result = await response.json();
    } catch {
      const text = await response.text();
      hideLockerLoading();
      showLockerAlert("error", "Payment failed — invalid server response:<br><small>" + text.slice(0, 120) + "...</small>");
      return;
    }

    hideLockerLoading();

    if (result.success) {
      const nextYear = new Date().getFullYear() + 1;
      showLockerAlert("success", `Payment successful! Locker booked for ${nextYear}.`);
      loadLockerBookings?.(); 
    } else {
      showLockerAlert("error", "Payment failed: " + (result.error || "Unknown error"));
    }
  } catch (err) {
    hideLockerLoading();
    showLockerAlert("error", "Payment could not be processed: " + err.message);
  } finally {
    confirmBtn.disabled = false;
    confirmBtn.innerHTML = `<i class="bi bi-check-circle"></i> Pay Now`;
  }
}
