-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 30, 2025 at 02:13 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `amandla_locker_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `AdminID` int(11) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`AdminID`, `Email`, `Password`, `Name`) VALUES
(2, '60378395@mylife.unisa.ac.za', '60378395', 'Eric');

-- --------------------------------------------------------

--
-- Table structure for table `lockers`
--

CREATE TABLE `lockers` (
  `LockerID` int(11) NOT NULL,
  `PhysicalLocation` varchar(100) NOT NULL,
  `Grade` enum('8','9','10','11','12') NOT NULL,
  `Status` enum('Available','Pending Payment','Booked','Cancelled') NOT NULL DEFAULT 'Available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lockers`
--

INSERT INTO `lockers` (`LockerID`, `PhysicalLocation`, `Grade`, `Status`) VALUES
(2, 'Junior Wing - Hallway A - Locker 2', '8', 'Available'),
(3, 'Junior Wing - Hallway A - Locker 3', '8', 'Cancelled'),
(4, 'Junior Wing - Hallway B - Locker 4', '8', 'Cancelled'),
(5, 'Junior Wing - Hallway B - Locker 5', '8', 'Cancelled'),
(6, 'Junior Wing - Near Library - Locker 6', '8', 'Cancelled'),
(7, 'Junior Wing - Science Passage - Locker 7', '8', 'Cancelled'),
(8, 'Junior Wing - Art Passage - Locker 8', '8', 'Cancelled'),
(9, 'Junior Wing - Music Passage - Locker 9', '8', 'Cancelled'),
(10, 'Junior Wing - East Entrance - Locker 10', '8', 'Cancelled'),
(11, 'North Wing - Corridor 1 - Locker 1', '9', 'Available'),
(12, 'North Wing - Corridor 1 - Locker 2', '9', 'Available'),
(13, 'North Wing - Corridor 1 - Locker 3', '9', 'Available'),
(14, 'North Wing - Corridor 2 - Locker 4', '9', 'Available'),
(15, 'North Wing - Corridor 2 - Locker 5', '9', 'Available'),
(16, 'North Wing - Corridor 3 - Locker 6', '9', 'Available'),
(17, 'North Wing - Corridor 3 - Locker 7', '9', 'Available'),
(18, 'North Wing - Corridor 4 - Locker 8', '9', 'Available'),
(19, 'North Wing - Corridor 4 - Locker 9', '9', 'Available'),
(20, 'North Wing - Corridor 5 - Locker 10', '9', 'Available'),
(21, 'North Wing - Science Lab Passage - Locker 11', '9', 'Available'),
(22, 'North Wing - Library Hall - Locker 12', '9', 'Available'),
(23, 'North Wing - Gym Hall - Locker 13', '9', 'Available'),
(24, 'North Wing - Gym Hall - Locker 14', '9', 'Available'),
(25, 'North Wing - Gym Hall - Locker 15', '9', 'Available'),
(26, 'East Wing - Row 1 - Locker 1', '10', 'Available'),
(27, 'East Wing - Row 1 - Locker 2', '10', 'Available'),
(28, 'East Wing - Row 1 - Locker 3', '10', 'Available'),
(29, 'East Wing - Row 2 - Locker 4', '10', 'Available'),
(30, 'East Wing - Row 2 - Locker 5', '10', 'Available'),
(31, 'East Wing - Row 2 - Locker 6', '10', 'Available'),
(32, 'East Wing - Row 3 - Locker 7', '10', 'Available'),
(33, 'East Wing - Row 3 - Locker 8', '10', 'Available'),
(34, 'East Wing - Row 3 - Locker 9', '10', 'Available'),
(35, 'East Wing - Row 4 - Locker 10', '10', 'Available'),
(36, 'East Wing - Library Corridor - Locker 11', '10', 'Available'),
(37, 'East Wing - Science Passage - Locker 12', '10', 'Available'),
(38, 'East Wing - Art Passage - Locker 13', '10', 'Available'),
(39, 'East Wing - Admin Passage - Locker 14', '10', 'Available'),
(40, 'East Wing - Near Cafeteria - Locker 15', '10', 'Available'),
(41, 'West Wing - Corridor 1 - Locker 1', '11', 'Available'),
(42, 'West Wing - Corridor 1 - Locker 2', '11', 'Available'),
(43, 'West Wing - Corridor 1 - Locker 3', '11', 'Available'),
(44, 'West Wing - Corridor 2 - Locker 4', '11', 'Pending Payment'),
(45, 'West Wing - Corridor 2 - Locker 5', '11', 'Available'),
(46, 'West Wing - Corridor 2 - Locker 6', '11', 'Available'),
(47, 'West Wing - Art Hall - Locker 7', '11', 'Available'),
(48, 'West Wing - Library Hall - Locker 8', '11', 'Available'),
(49, 'West Wing - Science Passage - Locker 9', '11', 'Available'),
(50, 'West Wing - Staff Hall - Locker 10', '11', 'Available'),
(51, 'West Wing - Gym Hall - Locker 11', '11', 'Available'),
(52, 'West Wing - Gym Hall - Locker 12', '11', 'Available'),
(53, 'West Wing - Music Hall - Locker 13', '11', 'Available'),
(54, 'West Wing - Music Hall - Locker 14', '11', 'Available'),
(55, 'West Wing - Near Cafeteria - Locker 15', '11', 'Available'),
(56, 'Senior Zone - Admin Hall - Locker 1', '12', 'Available'),
(57, 'Senior Zone - Admin Hall - Locker 2', '12', 'Available'),
(58, 'Senior Zone - Admin Hall - Locker 3', '12', 'Available'),
(59, 'Senior Zone - Hallway A - Locker 4', '12', 'Available'),
(60, 'Senior Zone - Hallway A - Locker 5', '12', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `locker_bookings`
--

CREATE TABLE `locker_bookings` (
  `BookingID` int(11) NOT NULL,
  `ParentID` int(11) NOT NULL,
  `StudentID` int(11) NOT NULL,
  `LockerID` int(11) NOT NULL,
  `BookingDate` datetime DEFAULT current_timestamp(),
  `Status` enum('Pending Payment','Booked','Cancelled') NOT NULL DEFAULT 'Pending Payment'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `parents`
--

CREATE TABLE `parents` (
  `ParentID` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Surname` varchar(50) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `City` varchar(100) NOT NULL,
  `Suburb` varchar(100) NOT NULL,
  `Town` varchar(100) NOT NULL,
  `PostalCode` varchar(20) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Cellphone` varchar(20) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `StudentID` int(11) NOT NULL,
  `ParentID` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Surname` varchar(50) NOT NULL,
  `Grade` enum('8','9','10','11','12') NOT NULL,
  `DateOfBirth` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `waitinglist`
--

CREATE TABLE `waitinglist` (
  `WaitingID` int(11) NOT NULL,
  `StudentID` int(11) NOT NULL,
  `Grade` enum('8','9','10','11','12') NOT NULL,
  `Status` enum('Active','Assigned','Cancelled') DEFAULT 'Active',
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`AdminID`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `lockers`
--
ALTER TABLE `lockers`
  ADD PRIMARY KEY (`LockerID`);

--
-- Indexes for table `locker_bookings`
--
ALTER TABLE `locker_bookings`
  ADD PRIMARY KEY (`BookingID`),
  ADD UNIQUE KEY `unique_student_active_booking` (`StudentID`),
  ADD KEY `ParentID` (`ParentID`),
  ADD KEY `LockerID` (`LockerID`);

--
-- Indexes for table `parents`
--
ALTER TABLE `parents`
  ADD PRIMARY KEY (`ParentID`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`StudentID`),
  ADD KEY `ParentID` (`ParentID`);

--
-- Indexes for table `waitinglist`
--
ALTER TABLE `waitinglist`
  ADD PRIMARY KEY (`WaitingID`),
  ADD KEY `StudentID` (`StudentID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `AdminID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `lockers`
--
ALTER TABLE `lockers`
  MODIFY `LockerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `locker_bookings`
--
ALTER TABLE `locker_bookings`
  MODIFY `BookingID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `parents`
--
ALTER TABLE `parents`
  MODIFY `ParentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `StudentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `waitinglist`
--
ALTER TABLE `waitinglist`
  MODIFY `WaitingID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `locker_bookings`
--
ALTER TABLE `locker_bookings`
  ADD CONSTRAINT `locker_bookings_ibfk_1` FOREIGN KEY (`ParentID`) REFERENCES `parents` (`ParentID`) ON DELETE CASCADE,
  ADD CONSTRAINT `locker_bookings_ibfk_2` FOREIGN KEY (`StudentID`) REFERENCES `students` (`StudentID`) ON DELETE CASCADE,
  ADD CONSTRAINT `locker_bookings_ibfk_3` FOREIGN KEY (`LockerID`) REFERENCES `lockers` (`LockerID`) ON DELETE CASCADE;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`ParentID`) REFERENCES `parents` (`ParentID`) ON DELETE CASCADE;

--
-- Constraints for table `waitinglist`
--
ALTER TABLE `waitinglist`
  ADD CONSTRAINT `waitinglist_ibfk_1` FOREIGN KEY (`StudentID`) REFERENCES `students` (`StudentID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
