<?php
session_start();

require('configs.php');
header("Content-Type: application/json");
if (!isset($_SESSION['ParentID'])) {
    echo json_encode(["status"=>"error","message"=>"Not logged in"]);
    exit;
}

$parentID = $_SESSION['ParentID'];


$name = $_POST['Name'] ?? '';
$surname = $_POST['Surname'] ?? '';
$grade = $_POST['Grade'] ?? '';
$dob = $_POST['DateOfBirth'] ?? '';

if (!$name || !$surname || !$grade || !$dob) {
    echo json_encode(["status"=>"error","message"=>"All fields required"]);
    exit;
}

$stmt = $conn->prepare("INSERT INTO students (ParentID, Name, Surname, Grade, DateOfBirth) VALUES (?,?,?,?,?)");
$stmt->bind_param("issss", $parentID, $name, $surname, $grade, $dob);

if ($stmt->execute()) {
    echo json_encode(["status"=>"success","message"=>"Student added"]);
} else {
    echo json_encode(["status"=>"error","message"=>"DB error: ".$conn->error]);
}

$stmt->close();
$conn->close();
