<?php

ob_clean(); 
header_remove();
header('Content-Type: application/xml; charset=utf-8');
header('Content-Disposition: attachment; filename="locker_reports_2026.xml"');

require_once './configs.php';


$totalLockers   = $conn->query("SELECT COUNT(*) AS c FROM lockers")->fetch_assoc()['c'] ?? 0;
$bookedLockers  = $conn->query("SELECT COUNT(*) AS c FROM locker_bookings WHERE Status='Booked'")->fetch_assoc()['c'] ?? 0;
$pending        = $conn->query("SELECT COUNT(*) AS c FROM locker_bookings WHERE Status='Pending Payment'")->fetch_assoc()['c'] ?? 0;
$cancelled      = $conn->query("SELECT COUNT(*) AS c FROM locker_bookings WHERE Status='Cancelled'")->fetch_assoc()['c'] ?? 0;
$revenue        = $bookedLockers * 150;


$trendSql = "
  SELECT DATE_FORMAT(BookingDate, '%Y-%m') AS month, COUNT(*) AS total
  FROM locker_bookings
  WHERE Status='Booked'
  GROUP BY month
  ORDER BY month ASC";
$trendRes = $conn->query($trendSql);


$gradeSql = "
  SELECT s.Grade, COUNT(lb.BookingID) AS total
  FROM locker_bookings lb
  INNER JOIN students s ON lb.StudentID = s.StudentID
  WHERE lb.Status='Booked'
  GROUP BY s.Grade
  ORDER BY s.Grade";
$gradeRes = $conn->query($gradeSql);

$xml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><LockerReports></LockerReports>');

$summary = $xml->addChild('Summary');
$summary->addChild('TotalLockers', $totalLockers);
$summary->addChild('BookedLockers', $bookedLockers);
$summary->addChild('PendingPayments', $pending);
$summary->addChild('Cancelled', $cancelled);
$summary->addChild('Revenue', $revenue);

$trendNode = $xml->addChild('MonthlyTrend');
while ($row = $trendRes->fetch_assoc()) {
    $m = $trendNode->addChild('Month');
    $m->addChild('Name', htmlspecialchars($row['month']));
    $m->addChild('Bookings', $row['total']);
}

$gradeNode = $xml->addChild('BookingsByGrade');
while ($row = $gradeRes->fetch_assoc()) {
    $g = $gradeNode->addChild('Grade');
    $g->addChild('Level', htmlspecialchars($row['Grade']));
    $g->addChild('Total', $row['total']);
}

echo $xml->asXML();
$conn->close();
exit;
