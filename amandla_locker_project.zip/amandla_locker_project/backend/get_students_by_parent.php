<?php
header('Content-Type: application/json');
require('configs.php');

$parentId = intval($_GET['parentId'] ?? 0);
if (!$parentId) {
    echo json_encode(["error" => "Invalid parent ID"]);
    exit;
}

$sql = "SELECT StudentID, Name, Surname, Grade, DateOfBirth FROM students WHERE ParentID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $parentId);
$stmt->execute();
$result = $stmt->get_result();

$students = [];
while ($row = $result->fetch_assoc()) $students[] = $row;

$stmt->close();
$conn->close();

echo json_encode(["students" => $students]);
