<?php
header('Content-Type: application/json');
require_once './configs.php';

$waitingID = $_POST['WaitingID'] ?? null;
if (!$waitingID) {
  echo json_encode(['success' => false, 'error' => 'Missing WaitingID']);
  exit;
}

$q = $conn->prepare("SELECT * FROM waitinglist WHERE WaitingID=? AND Status='Active'");
$q->bind_param("i", $waitingID);
$q->execute();
$w = $q->get_result()->fetch_assoc();
if (!$w) {
  echo json_encode(['success' => false, 'error' => 'Invalid waiting record']);
  exit;
}
$grade = $w['Grade'];
$studentID = $w['StudentID'];

$l = $conn->prepare("SELECT LockerID FROM lockers WHERE Grade=? AND Status='Available' LIMIT 1");
$l->bind_param("s", $grade);
$l->execute();
$locker = $l->get_result()->fetch_assoc();

if (!$locker) {
  echo json_encode(['success' => false, 'error' => 'No available locker for this grade']);
  exit;
}
$lockerID = $locker['LockerID'];

$p = $conn->prepare("SELECT ParentID FROM students WHERE StudentID=?");
$p->bind_param("i", $studentID);
$p->execute();
$parent = $p->get_result()->fetch_assoc();
$parentID = $parent['ParentID'] ?? null;

$ins = $conn->prepare("INSERT INTO locker_bookings (ParentID, StudentID, LockerID, BookingDate, Status) VALUES (?, ?, ?, NOW(), 'Pending Payment')");
$ins->bind_param("iii", $parentID, $studentID, $lockerID);
$ins->execute();


$conn->query("UPDATE lockers SET Status='Pending Payment' WHERE LockerID=$lockerID");
$conn->query("UPDATE waitinglist SET Status='Assigned' WHERE WaitingID=$waitingID");

echo json_encode(['success' => true, 'message' => 'Locker assigned successfully']);
