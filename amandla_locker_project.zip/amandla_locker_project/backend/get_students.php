<?php
session_start();
require('configs.php');
header("Content-Type: application/json");

if (!isset($_SESSION['ParentID'])) {
    echo json_encode([]);
    exit;
}

$parentID = $_SESSION['ParentID'];

if ($conn->connect_error) {
    echo json_encode([]);
    exit;
}

$stmt = $conn->prepare("SELECT StudentID, Name, Surname, Grade, DateOfBirth 
                        FROM students WHERE ParentID = ?");
$stmt->bind_param("i", $parentID);
$stmt->execute();
$result = $stmt->get_result();

$students = [];
while ($row = $result->fetch_assoc()) {
    $students[] = $row;
}

echo json_encode($students);

$stmt->close();
$conn->close();
?>
