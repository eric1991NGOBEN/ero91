<?php

header('Content-Type: application/json');



session_start();

require('configs.php');
if (!$conn) {
    echo json_encode(['success' => false, 'error' => 'Database connection failed']);
    exit;
}

$location = $_POST['PhysicalLocation'] ?? null;
$grade    = $_POST['Grade'] ?? null;


if (!$location || !$grade) {
    echo json_encode(['success' => false, 'error' => 'Missing locker location or grade']);
    exit;
}

$validGrades = ['8','9','10','11','12'];
if (!in_array($grade, $validGrades)) {
    echo json_encode(['success' => false, 'error' => 'Invalid grade']);
    exit;
}


$sql = "INSERT INTO lockers (PhysicalLocation, Grade, Status) VALUES (?, ?, 'Available')";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $location, $grade);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => $stmt->error]);
}

$stmt->close();
$conn->close();
