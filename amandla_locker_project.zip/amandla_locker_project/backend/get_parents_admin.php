<?php
header('Content-Type: application/json');
require_once './configs.php';

$response = ['parents' => [], 'currentPage' => 1, 'totalPages' => 1, 'error' => null];

if (!$conn) {
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

$page   = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$limit  = 10;
$offset = ($page - 1) * $limit;


try {
    if ($search !== '') {
        $countSql = "SELECT COUNT(*) AS total 
                     FROM parents 
                     WHERE Name LIKE ? OR Surname LIKE ? OR Email LIKE ? OR City LIKE ?";
        $stmt = $conn->prepare($countSql);
        $searchLike = "%$search%";
        $stmt->bind_param('ssss', $searchLike, $searchLike, $searchLike, $searchLike);
    } else {
        $countSql = "SELECT COUNT(*) AS total FROM parents";
        $stmt = $conn->prepare($countSql);
    }

    $stmt->execute();
    $totalRows = $stmt->get_result()->fetch_assoc()['total'] ?? 0;
    $stmt->close();
} catch (Exception $e) {
    echo json_encode(['error' => 'Count query failed: ' . $e->getMessage()]);
    exit;
}

$totalPages = max(1, ceil($totalRows / $limit));

try {
    if ($search !== '') {
        $sql = "SELECT ParentID, Name, Surname, Email, Cellphone, City 
                FROM parents 
                WHERE Name LIKE ? OR Surname LIKE ? OR Email LIKE ? OR City LIKE ?
                ORDER BY ParentID DESC
                LIMIT ?, ?";
        $stmt = $conn->prepare($sql);
        $searchLike = "%$search%";
        $stmt->bind_param('ssssii', $searchLike, $searchLike, $searchLike, $searchLike, $offset, $limit);
    } else {
        $sql = "SELECT ParentID, Name, Surname, Email, Cellphone, City 
                FROM parents 
                ORDER BY ParentID DESC
                LIMIT ?, ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ii', $offset, $limit);
    }

    $stmt->execute();
    $result = $stmt->get_result();

    $parents = [];
    while ($row = $result->fetch_assoc()) {
        $parents[] = $row;
    }
    $stmt->close();
} catch (Exception $e) {
    echo json_encode(['error' => 'Data query failed: ' . $e->getMessage()]);
    exit;
}


echo json_encode([
    'parents' => $parents,
    'currentPage' => $page,
    'totalPages' => $totalPages,
    'totalRows' => $totalRows
]);

$conn->close();
