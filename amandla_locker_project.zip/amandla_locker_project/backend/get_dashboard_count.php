<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once './configs.php'; 

if (!$conn) {
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

$data = [
    'totalLockers'   => 0,
    'bookedLockers'  => 0,
    'totalParents'   => 0,
    'totalStudents'  => 0,
    'totalAdmins'    => 0
];



$sql = "SELECT COUNT(*) AS cnt FROM lockers";
$result = $conn->query($sql);
if ($result && $row = $result->fetch_assoc()) {
    $data['totalLockers'] = (int)$row['cnt'];
}

//lockers with Status = 'Booked'
$sql = "SELECT COUNT(*) AS cnt FROM lockers WHERE Status = 'Booked'";
$result = $conn->query($sql);
if ($result && $row = $result->fetch_assoc()) {
    $data['bookedLockers'] = (int)$row['cnt'];
}


$sql = "SELECT COUNT(*) AS cnt FROM parents";
$result = $conn->query($sql);
if ($result && $row = $result->fetch_assoc()) {
    $data['totalParents'] = (int)$row['cnt'];
}


$sql = "SELECT COUNT(*) AS cnt FROM students";
$result = $conn->query($sql);
if ($result && $row = $result->fetch_assoc()) {
    $data['totalStudents'] = (int)$row['cnt'];
}


$sql = "SELECT COUNT(*) AS cnt FROM admins";
$result = $conn->query($sql);
if ($result && $row = $result->fetch_assoc()) {
    $data['totalAdmins'] = (int)$row['cnt'];
}

$conn->close();

echo json_encode($data);
?>