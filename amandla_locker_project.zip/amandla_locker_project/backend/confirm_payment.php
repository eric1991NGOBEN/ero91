<?php
header('Content-Type: application/json');
require_once './configs.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit;
}

$bookingID = isset($_POST['BookingID']) ? intval($_POST['BookingID']) : 0;

if ($bookingID <= 0) {
    echo json_encode(['success' => false, 'error' => 'Booking ID missing or invalid']);
    exit;
}

try {
    $stmt = $conn->prepare("SELECT LockerID FROM locker_bookings WHERE BookingID = ?");
    $stmt->bind_param("i", $bookingID);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();

    if (!$row) {
        echo json_encode(['success' => false, 'error' => 'Booking not found']);
        exit;
    }

    $lockerID = intval($row['LockerID']);

    $stmt = $conn->prepare("UPDATE locker_bookings SET Status = 'Booked' WHERE BookingID = ?");
    $stmt->bind_param("i", $bookingID);
    if (!$stmt->execute()) {
        throw new Exception("Failed to update locker_bookings");
    }
    $stmt->close();

    if ($lockerID > 0) {
        $stmt = $conn->prepare("UPDATE lockers SET Status = 'Booked' WHERE LockerID = ?");
        $stmt->bind_param("i", $lockerID);
        $stmt->execute();
        $stmt->close();
    }


    echo json_encode(['success' => true]);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
