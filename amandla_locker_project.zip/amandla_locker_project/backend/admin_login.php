<?php
header('Content-Type: application/json');
session_start();

require_once './configs.php'; 


$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

if (empty($email) || empty($password)) {
    echo json_encode(["status" => "error", "message" => "Please fill in both fields."]);
    exit;
}

$stmt = $conn->prepare("SELECT AdminID, Name, Password FROM admins WHERE Email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $admin = $result->fetch_assoc();

    if ($password === $admin['Password']) {
        $_SESSION['AdminID'] = $admin['AdminID'];
        $_SESSION['AdminName'] = $admin['Name'];
        $_SESSION['AdminEmail'] = $email;

        echo json_encode([
            "status" => "success",
            "message" => "Login successful.",
            "name" => $admin['Name']
        ]);
    } else {
        echo json_encode(["status" => "error", "message" => "Incorrect password."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Admin not found."]);
}

$stmt->close();
$conn->close();
?>
