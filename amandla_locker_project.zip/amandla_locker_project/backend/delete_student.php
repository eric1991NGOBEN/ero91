<?php
session_start();

require('configs.php');
header("Content-Type: application/json");
if (!isset($_SESSION['ParentID'])) { echo json_encode(["status"=>"error"]); exit; }

$studentID = $_POST['StudentID'] ?? 0;


$stmt = $conn->prepare("DELETE FROM students WHERE StudentID=? AND ParentID=?");
$stmt->bind_param("ii", $studentID, $_SESSION['ParentID']);
$stmt->execute();

echo json_encode(["status"=>"success"]);
