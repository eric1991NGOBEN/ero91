<?php
require('configs.php');
header('Content-Type: application/json');
session_start();

if (!isset($_SESSION['ParentID'])) {
    echo json_encode(["status" => "error", "message" => "Unauthorized"]);
    exit;
}

$grade = $_GET['grade'] ?? '';



$stmt = $conn->prepare("SELECT LockerID, PhysicalLocation FROM lockers WHERE Grade = ? AND Status = 'Available'");
$stmt->bind_param("s", $grade);
$stmt->execute();
$result = $stmt->get_result();

$lockers = [];
while ($row = $result->fetch_assoc()) {
    $lockers[] = $row;
}

$stmt->close();
$conn->close();

echo json_encode($lockers);
exit;
?>
