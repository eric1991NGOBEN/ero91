
<?php
// DATABASE connection
$servername = "localhost";
$username = "root";   
$password = "";       
$dbname = "amandla_locker_project";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed"]);
    exit;
}
?>