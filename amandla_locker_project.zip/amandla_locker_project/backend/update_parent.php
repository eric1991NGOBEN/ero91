<?php
header('Content-Type: application/json');
require_once 'configs.php';

$id = $_POST['ParentID'] ?? null;
$name = $_POST['Name'] ?? '';
$surname = $_POST['Surname'] ?? '';
$email = $_POST['Email'] ?? '';
$cell = $_POST['Cellphone'] ?? '';
$city = $_POST['City'] ?? '';

if (!$id) {
  echo json_encode(['error' => 'Missing Parent ID']);
  exit;
}

$stmt = $conn->prepare("UPDATE parents SET Name=?, Surname=?, Email=?, Cellphone=?, City=? WHERE ParentID=?");
$stmt->bind_param("sssssi", $name, $surname, $email, $cell, $city, $id);

if ($stmt->execute()) {
  echo json_encode(['success' => true]);
} else {
  echo json_encode(['error' => 'Database update failed.']);
}