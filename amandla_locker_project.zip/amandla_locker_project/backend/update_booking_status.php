<?php
header('Content-Type: application/json');
require_once './configs.php';

$bookingID = $_POST['BookingID'] ?? null;
$newStatus = $_POST['Status'] ?? null;

if (!$bookingID || !$newStatus) {
  echo json_encode(['success' => false, 'error' => 'Missing parameters']);
  exit;
}

$stmt = $conn->prepare("UPDATE locker_bookings SET Status=? WHERE BookingID=?");
$stmt->bind_param("si", $newStatus, $bookingID);

if ($stmt->execute()) {
  echo json_encode(['success' => true]);
} else {
  echo json_encode(['success' => false, 'error' => $stmt->error]);
}

$stmt->close();
$conn->close();
