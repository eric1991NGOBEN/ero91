<?php

header('Content-Type: application/json');
require_once './configs.php';

if (!$conn) {
    echo json_encode(['success' => false, 'error' => 'Database connection failed']);
    exit;
}

$lockerId  = $_POST['LockerID'] ?? null;
$location  = $_POST['PhysicalLocation'] ?? null;
$grade     = $_POST['Grade'] ?? null;
$status    = $_POST['Status'] ?? null;

if (!$lockerId || !$location || !$grade || !$status) {
    echo json_encode(['success' => false, 'error' => 'Missing required parameters']);
    exit;
}


$validGrades = ['8','9','10','11','12'];
if (!in_array($grade, $validGrades)) {
    echo json_encode(['success' => false, 'error' => 'Invalid grade value']);
    exit;
}


$sql = "UPDATE lockers SET PhysicalLocation = ?, Grade = ?, Status = ? WHERE LockerID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssi", $location, $grade, $status, $lockerId);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => $stmt->error]);
}

$stmt->close();
$conn->close();
