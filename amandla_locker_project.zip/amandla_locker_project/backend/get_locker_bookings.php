<?php
require('configs.php');
header('Content-Type: application/json');
session_start();

if (!isset($_SESSION['ParentID'])) {
    echo json_encode(["status" => "error", "message" => "Unauthorized access"]);
    exit;
}

$parentID = $_SESSION['ParentID'];


$sql = "
    SELECT 
        s.StudentID,
        s.Name,
        s.Surname,
        s.Grade,
        lb.BookingID,
        lb.Status AS BookingStatus,
        l.LockerID,
        l.PhysicalLocation AS LockerLocation
    FROM students s
    LEFT JOIN locker_bookings lb ON s.StudentID = lb.StudentID
    LEFT JOIN lockers l ON lb.LockerID = l.LockerID
    WHERE s.ParentID = ?
    ORDER BY s.Name ASC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $parentID);
$stmt->execute();
$result = $stmt->get_result();

$bookings = [];
while ($row = $result->fetch_assoc()) {
    $bookings[] = $row;
}

$stmt->close();
$conn->close();

echo json_encode($bookings);
exit;
?>
