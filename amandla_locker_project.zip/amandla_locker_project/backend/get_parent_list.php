<?php
header("Content-Type: application/json");
require('configs.php');

if (!$conn) {
    echo json_encode(["error" => "Database connection failed"]);
    exit;
}

$sql = "SELECT ParentID, Name, Surname, Email FROM parents ORDER BY Name ASC";
$result = $conn->query($sql);

$parents = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $parents[] = [
            "ParentID" => (int)$row["ParentID"],
            "DisplayName" => "{$row['Name']} {$row['Surname']} ({$row['Email']})"
        ];
    }
}

$conn->close();
echo json_encode(["parents" => $parents]);
