<?php
header('Content-Type: application/json');

require('configs.php');

$name       = $_POST['Name'] ?? '';
$surname    = $_POST['Surname'] ?? '';
$address    = $_POST['Address'] ?? '';
$city       = $_POST['City'] ?? '';
$suburb     = $_POST['Suburb'] ?? '';
$town       = $_POST['Town'] ?? '';
$postalCode = $_POST['PostalCode'] ?? '';
$email      = $_POST['Email'] ?? '';
$cellphone  = $_POST['Cellphone'] ?? '';
$password   = $_POST['Password'] ?? '';

// Basic validation
if (empty($name) || empty($surname) || empty($email) || empty($password)) {
    echo json_encode(["status" => "error", "message" => "Please fill all required fields."]);
    exit;
}

// Hash password
$hashedPassword = password_hash($password, PASSWORD_BCRYPT);

$stmt = $conn->prepare("INSERT INTO parents 
    (Name, Surname, Address, City, Suburb, Town, PostalCode, Email, Cellphone, Password)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssssss", $name, $surname, $address, $city, $suburb, $town, $postalCode, $email, $cellphone, $hashedPassword);

try {
    $stmt->execute();
    echo json_encode(["status" => "success", "message" => "Parent registered successfully!"]);
} catch (mysqli_sql_exception $e) {
    if ($conn->errno === 1062) {
        echo json_encode(["status" => "error", "message" => "Email already exists!"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Database error: " . $e->getMessage()]);
    }
}

$stmt->close();
$conn->close();
