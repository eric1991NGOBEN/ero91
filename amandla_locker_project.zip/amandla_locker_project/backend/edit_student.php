<?php
session_start();
require('configs.php');
header("Content-Type: application/json");
if (!isset($_SESSION['ParentID'])) {
    echo json_encode(["status"=>"error","message"=>"Not logged in"]);
    exit;
}

$parentID  = $_SESSION['ParentID'];
$studentID = $_POST['StudentID'] ?? 0;
$name      = $_POST['Name'] ?? '';
$surname   = $_POST['Surname'] ?? '';
$grade     = $_POST['Grade'] ?? '';
$dob       = $_POST['DateOfBirth'] ?? '';

if (!$studentID || !$name || !$surname || !$grade || !$dob) {
    echo json_encode(["status"=>"error","message"=>"All fields required"]);
    exit;
}



$stmt = $conn->prepare("UPDATE students SET Name=?, Surname=?, Grade=?, DateOfBirth=? WHERE StudentID=? AND ParentID=?");
$stmt->bind_param("ssssii", $name, $surname, $grade, $dob, $studentID, $parentID);

if ($stmt->execute()) {
    echo json_encode(["status"=>"success","message"=>"Student updated"]);
} else {
    echo json_encode(["status"=>"error","message"=>"DB error: ".$conn->error]);
}

$stmt->close();
$conn->close();
