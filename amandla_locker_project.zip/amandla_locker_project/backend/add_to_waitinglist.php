<?php
header('Content-Type: application/json');
require_once './configs.php';
session_start();

$studentID = $_POST['StudentID'] ?? null;
$grade = $_POST['Grade'] ?? null;

if (!$studentID || !$grade) {
  echo json_encode(['success' => false, 'error' => 'Missing parameters']);
  exit;
}


$check = $conn->prepare("SELECT WaitingID FROM waitinglist WHERE StudentID=? AND Status='Active'");
$check->bind_param("i", $studentID);
$check->execute();
if ($check->get_result()->num_rows > 0) {
  echo json_encode(['success' => false, 'error' => 'Student already on waiting list']);
  exit;
}

$stmt = $conn->prepare("INSERT INTO waitinglist (StudentID, Grade, Status) VALUES (?, ?, 'Active')");
$stmt->bind_param("is", $studentID, $grade);

if ($stmt->execute()) {
  echo json_encode(['success' => true, 'message' => 'Student added to waiting list']);
} else {
  echo json_encode(['success' => false, 'error' => $stmt->error]);
}

$stmt->close();
$conn->close();
