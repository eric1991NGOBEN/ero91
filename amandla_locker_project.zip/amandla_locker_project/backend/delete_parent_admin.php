<?php
header('Content-Type: application/json');
require_once '../connect.php';
$parentId = $_GET['parentId'] ?? null;
if (!$parentId) {
  echo json_encode(['error' => 'Missing parent ID']);
  exit;
}

$stmt = $conn->prepare("SELECT StudentID, Name, Surname, Grade, DateOfBirth FROM students WHERE ParentID=? ORDER BY Grade ASC");
$stmt->bind_param("i", $parentId);
$stmt->execute();
$result = $stmt->get_result();

$students = [];
while ($row = $result->fetch_assoc()) {
  $students[] = $row;
}

echo json_encode(['students' => $students]);
?>