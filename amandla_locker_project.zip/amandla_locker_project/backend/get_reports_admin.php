<?php
header('Content-Type: application/json');
require_once './configs.php';


$totalLockers = $conn->query("SELECT COUNT(*) AS c FROM lockers")->fetch_assoc()['c'] ?? 0;


$bookedLockers = $conn->query("SELECT COUNT(*) AS c FROM locker_bookings WHERE Status='Booked'")->fetch_assoc()['c'] ?? 0;


$pendingLockers = $conn->query("SELECT COUNT(*) AS c FROM locker_bookings WHERE Status='Pending Payment'")->fetch_assoc()['c'] ?? 0;
$cancelledLockers = $conn->query("SELECT COUNT(*) AS c FROM locker_bookings WHERE Status='Cancelled'")->fetch_assoc()['c'] ?? 0;


$revenue = $bookedLockers * 150;

$trendSql = "
  SELECT DATE_FORMAT(BookingDate, '%Y-%m') AS month, COUNT(*) AS total
  FROM locker_bookings
  WHERE Status='Booked'
  GROUP BY month
  ORDER BY month ASC";
$trendRes = $conn->query($trendSql);
$monthlyTrend = [];
while ($r = $trendRes->fetch_assoc()) $monthlyTrend[] = $r;

$gradeSql = "
  SELECT s.Grade, COUNT(lb.BookingID) AS total
  FROM locker_bookings lb
  INNER JOIN students s ON lb.StudentID = s.StudentID
  WHERE lb.Status='Booked'
  GROUP BY s.Grade
  ORDER BY s.Grade";
$gradeRes = $conn->query($gradeSql);
$bookingsByGrade = [];
while ($r = $gradeRes->fetch_assoc()) $bookingsByGrade[] = $r;

echo json_encode([
  'summary' => [
    'totalLockers' => $totalLockers,
    'bookedLockers' => $bookedLockers,
    'pending' => $pendingLockers,
    'cancelled' => $cancelledLockers,
    'revenue' => $revenue
  ],
  'monthlyTrend' => $monthlyTrend,
  'bookingsByGrade' => $bookingsByGrade
]);
