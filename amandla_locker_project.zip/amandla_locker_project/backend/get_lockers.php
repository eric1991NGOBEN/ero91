<?php

header('Content-Type: application/json');

require('configs.php');

$limit = 10;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $limit;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$searchClause = '';
if ($search !== '') {
    $like = "%" . $conn->real_escape_string($search) . "%";
    $searchClause = "WHERE PhysicalLocation LIKE '$like' OR Grade LIKE '$like' OR Status LIKE '$like'";
}

$countQuery = "SELECT COUNT(*) AS total FROM lockers $searchClause";
$countResult = $conn->query($countQuery);
$totalRows = ($countResult && $row = $countResult->fetch_assoc()) ? intval($row['total']) : 0;
$totalPages = ceil($totalRows / $limit);

$sql = "SELECT LockerID, PhysicalLocation, Grade, Status FROM lockers $searchClause ORDER BY LockerID ASC LIMIT $limit OFFSET $offset";
$result = $conn->query($sql);

$lockers = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $lockers[] = $row;
    }
}

$conn->close();

echo json_encode([
    'lockers' => $lockers,
    'totalPages' => $totalPages,
    'currentPage' => $page,
    'totalRows' => $totalRows
]);