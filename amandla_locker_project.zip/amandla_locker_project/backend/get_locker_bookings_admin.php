<?php
header('Content-Type: application/json');
require_once './configs.php';

$sql = "
  SELECT 
    b.BookingID,
    b.Status,
    b.BookingDate,
    s.Name AS StudentName,
    s.Surname AS StudentSurname,
    s.Grade AS StudentGrade,
    l.PhysicalLocation AS LockerLocation,
    p.Name AS ParentName,
    p.Surname AS ParentSurname
  FROM locker_bookings b
  LEFT JOIN students s ON b.StudentID = s.StudentID
  LEFT JOIN lockers l ON b.LockerID = l.LockerID
  LEFT JOIN parents p ON b.ParentID = p.ParentID
  ORDER BY b.BookingDate DESC
";
$result = $conn->query($sql);

$bookings = [];
if ($result && $result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $bookings[] = $row;
  }
}

$conn->close();

echo json_encode(['bookings' => $bookings]);
