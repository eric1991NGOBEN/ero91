<?php
session_start();
header('Content-Type: application/json');

require('configs.php');
$email = $_POST['Email'] ?? '';
$password = $_POST['Password'] ?? '';

if (empty($email) || empty($password)) {
    echo json_encode(["status" => "error", "message" => "Email and password are required."]);
    exit;
}

// Find parent by email
$stmt = $conn->prepare("SELECT ParentID, Name, Surname, Email, Password FROM parents WHERE Email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["status" => "error", "message" => "No account found with that email."]);
    exit;
}

$row = $result->fetch_assoc();

if (password_verify($password, $row['Password'])) {
    //Save session data
    $_SESSION['ParentID'] = $row['ParentID'];
    $_SESSION['Email']    = $row['Email'];
    $_SESSION['Names']    = $row['Name'] . " " . $row['Surname'];

    echo json_encode([
        "status" => "success",
        "message" => "Login successful!",
        "parentID" => $row['ParentID'],
        "email" => $row['Email']
    ]);
} else {
    echo json_encode(["status" => "error", "message" => "Invalid password."]);
}

$stmt->close();
$conn->close();
?>