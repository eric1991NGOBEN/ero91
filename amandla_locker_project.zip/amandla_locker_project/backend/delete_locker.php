<?php

header('Content-Type: application/json');
require_once './configs.php'; 

if (!$conn) {
    echo json_encode(['success' => false, 'error' => 'Database connection failed']);
    exit;
}

$lockerId = $_POST['LockerID'] ?? null;

if (!$lockerId) {
    echo json_encode(['success' => false, 'error' => 'Locker ID missing']);
    exit;
}

$sql = "DELETE FROM lockers WHERE LockerID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $lockerId);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => $stmt->error]);
}

$stmt->close();
$conn->close();
