<?php

require('configs.php');
header("Content-Type: application/json");


$parentID = $_POST['ParentID'] ?? '';
$name = $_POST['Name'] ?? '';
$surname = $_POST['Surname'] ?? '';
$grade = $_POST['Grade'] ?? '';
$dob = $_POST['DateOfBirth'] ?? '';

if (!$parentID || !$name || !$surname || !$grade || !$dob) {
    echo json_encode(["success" => false, "error" => "All fields are required."]);
    exit;
}


$check = $conn->prepare("SELECT ParentID FROM parents WHERE ParentID = ?");
$check->bind_param("i", $parentID);
$check->execute();
$checkResult = $check->get_result();

if ($checkResult->num_rows === 0) {
    echo json_encode(["success" => false, "error" => "Parent not found."]);
    exit;
}
$check->close();

$stmt = $conn->prepare("INSERT INTO students (ParentID, Name, Surname, Grade, DateOfBirth) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("issss", $parentID, $name, $surname, $grade, $dob);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Student added successfully."]);
} else {
    echo json_encode(["success" => false, "error" => "DB Error: " . $stmt->error]);
}

$stmt->close();
$conn->close();
