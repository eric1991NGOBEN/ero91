<?php
header('Content-Type: application/json');


require('configs.php');
if (!$conn) {
    echo json_encode(['success' => false, 'error' => 'Database connection failed']);
    exit;
}

$studentId  = $_POST['StudentID'] ?? null;
$parentId   = $_POST['ParentID'] ?? null;
$name       = $_POST['Name'] ?? null;
$surname    = $_POST['Surname'] ?? null;
$grade      = $_POST['Grade'] ?? null;
$dob        = $_POST['DateOfBirth'] ?? null;

if (!$studentId || !$name || !$surname || !$grade || !$dob) {
    echo json_encode(['success' => false, 'error' => 'Missing required fields']);
    exit;
}

$validGrades = ['8','9','10','11','12'];
if (!in_array($grade, $validGrades)) {
    echo json_encode(['success' => false, 'error' => 'Invalid grade']);
    exit;
}

$sql = "UPDATE students SET ParentID = ?, Name = ?, Surname = ?, Grade = ?, DateOfBirth = ? WHERE StudentID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("issssi", $parentId, $name, $surname, $grade, $dob, $studentId);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => $stmt->error]);
}

$stmt->close();
$conn->close();
