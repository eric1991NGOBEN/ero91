<?php

header('Content-Type: application/json');
require_once './configs.php';

if (!$conn) {
    echo json_encode(['success' => false, 'error' => 'Database connection failed']);
    exit;
}

$studentId = $_POST['StudentID'] ?? null;
if (!$studentId) {
    echo json_encode(['success' => false, 'error' => 'Missing student ID']);
    exit;
}

$sql = "DELETE FROM students WHERE StudentID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $studentId);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => $stmt->error]);
}

$stmt->close();
$conn->close();
