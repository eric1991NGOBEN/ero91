<?php
header('Content-Type: application/json');
require_once './configs.php';
if (!$conn || $conn->connect_error) {
    echo json_encode(['error' => 'Database connection failed: ' . $conn->connect_error]);
    exit;
}


$limit = 10;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $limit;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$whereSQL = '';
$params = [];
$types = '';

if ($search !== '') {
    $whereSQL = "WHERE s.Name LIKE ? OR s.Surname LIKE ? OR s.Grade LIKE ?";
    $like = "%$search%";
    $params = [$like, $like, $like];
    $types = 'sss';
}

$countSql = "SELECT COUNT(*) AS total FROM students s $whereSQL";
$stmt = $conn->prepare($countSql);
if ($whereSQL !== '') $stmt->bind_param($types, ...$params);
$stmt->execute();
$countResult = $stmt->get_result();
$totalRows = ($countResult && $row = $countResult->fetch_assoc()) ? intval($row['total']) : 0;
$totalPages = ceil($totalRows / $limit);
$stmt->close();

$sql = "
    SELECT 
        s.StudentID,
        s.ParentID,
        s.Name,
        s.Surname,
        s.Grade,
        s.DateOfBirth,
        COALESCE(CONCAT(p.Name, ' ', p.Surname), CONCAT('Parent ID: ', s.ParentID)) AS ParentDisplay
    FROM students s
    LEFT JOIN parents p ON s.ParentID = p.ParentID
    $whereSQL
    ORDER BY s.StudentID ASC
    LIMIT ? OFFSET ?
";


$stmt = $conn->prepare($sql);
if ($whereSQL !== '') {
    $params[] = $limit;
    $params[] = $offset;
    $stmt->bind_param($types . "ii", ...$params);
} else {
    $stmt->bind_param("ii", $limit, $offset);
}

$stmt->execute();
$result = $stmt->get_result();

$students = [];
while ($row = $result->fetch_assoc()) {
    $students[] = $row;
}

$stmt->close();
$conn->close();

echo json_encode([
    'students' => $students,
    'totalPages' => $totalPages,
    'currentPage' => $page,
    'totalRows' => $totalRows
]);
exit;