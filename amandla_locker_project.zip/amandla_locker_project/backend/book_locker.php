<?php
session_start();
require('configs.php');
header("Content-Type: application/json");
if (!isset($_SESSION['ParentID'])) {
    echo json_encode(["status"=>"error","message"=>"Not logged in."]);
    exit;
}

$parentID = $_SESSION['ParentID'];
$studentID = $_POST['StudentID'] ?? 0;
$lockerID  = $_POST['LockerID'] ?? 0;


$student = $conn->query("SELECT Grade FROM students WHERE StudentID=$studentID AND ParentID=$parentID")->fetch_assoc();
if (!$student) {
    echo json_encode(["status"=>"error","message"=>"Invalid student."]);
    exit;
}


$locker = $conn->query("SELECT Grade, Status FROM lockers WHERE LockerID=$lockerID")->fetch_assoc();
if (!$locker) {
    echo json_encode(["status"=>"error","message"=>"Invalid locker."]);
    exit;
}


if ($student['Grade'] !== $locker['Grade']) {
    echo json_encode(["status"=>"error","message"=>"Locker must match student’s grade."]);
    exit;
}

//Prevent double booking
$exists = $conn->query("SELECT * FROM locker_bookings WHERE StudentID=$studentID AND Status IN ('Pending Payment','Booked')");
if ($exists->num_rows > 0) {
    echo json_encode(["status"=>"error","message"=>"Student already has a locker booked."]);
    exit;
}


$stmt = $conn->prepare("INSERT INTO locker_bookings (LockerID, StudentID, ParentID, Status) VALUES (?, ?, ?, 'Pending Payment')");
$stmt->bind_param("iii", $lockerID, $studentID, $parentID);

if ($stmt->execute()) {
    $conn->query("UPDATE lockers SET Status='Pending Payment' WHERE LockerID=$lockerID");
    echo json_encode(["status"=>"success","message"=>"Locker booking submitted (Pending Payment)."]);
} else {
    echo json_encode(["status"=>"error","message"=>"Database error: ".$conn->error]);
}

$stmt->close();
$conn->close();
?>
