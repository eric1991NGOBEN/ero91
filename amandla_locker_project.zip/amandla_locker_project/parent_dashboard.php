<?php
session_start();
if (!isset($_SESSION['ParentID'])) {
    header("Location: index.php");
    exit;
}

$parentNames = $_SESSION['Names'];
$parentEmail = $_SESSION['Email'];
$parentID = $_SESSION['ParentID'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Amandla High School Locker System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">

      <!-- JS FILE FOR STUDENTSLOGIC -->
  <script src="./js/student.js"></script>
        <!-- JS FILE FOR LOCKER LOGIC -->
  <script src="./js/locker.js"></script>
  <!-- Google Font -->
  <link href="https://fonts.googleapis.com/css2?family=Feeling:%2FExpressive%2FCalm:wght@600&display=swap" rel="stylesheet">

  <style>

    .locker-loading {
    border-radius: 20px;
    border: 3px solid #b71c1c;
    background: linear-gradient(145deg, #f9f9f9, #e0e0e0);
    box-shadow: 6px 6px 15px rgba(0,0,0,0.3), -4px -4px 10px rgba(255,255,255,0.7);
    padding: 30px;
    }

    .locker-spinner {
    width: 60px;
    height: 60px;
    border: 6px solid #ccc;
    border-top: 6px solid #b71c1c;
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin: 0 auto;
    }

    @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
    }

    .locker-alert {
    border-radius: 20px;
    border: 3px solid #b71c1c;
    background: linear-gradient(145deg, #f9f9f9, #e0e0e0);
    box-shadow: 6px 6px 15px rgba(0,0,0,0.3), -4px -4px 10px rgba(255,255,255,0.7);
    }
    .locker-header {
    border-bottom: 2px solid #ccc;
    border-top-left-radius: 18px;
    border-top-right-radius: 18px;
    background: #b71c1c;
    color: #fff;
    }

    body {
      background: linear-gradient(135deg, #eec6c6ff, #f5f5f5);
      font-family: 'Edu SA Beginner', cursive;
      min-height: 100vh;
      padding: 20px;
    }
    .dashboard-card {
      background: #fff;
      border-radius: 15px;
      padding: 30px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.15);
      max-width: 900px;
      margin: auto;
    }
    .system-title {
      font-size: 1.8rem;
      font-weight: bold;
      margin-bottom: 10px;
      color: #b71c1c;
      text-align: center;
    }
    .nav-tabs .nav-link.active {
      background-color: #b71c1c !important;
      color: #fff !important;
      border-radius: 10px 10px 0 0;
    }
    .nav-tabs .nav-link {
      font-weight: bold;
      color: #b71c1c;
    }
    .tab-content {
      margin-top: 20px;
    }
  </style>
</head>
<body>
  <div class="dashboard-card">
    <div class="system-title">Amandla High School<br>Locker System</div>

>
    <div class="mb-3 text-center">
      <h4>Welcome, <?php echo htmlspecialchars($parentNames); ?></h4>
      <a href="logout_parent.php" class="btn btn-outline-danger btn-sm">Logout</a>
    </div>

    <ul class="nav nav-tabs justify-content-center" id="parentTabs" role="tablist">
      <li class="nav-item">
        <button class="nav-link active" id="students-tab" data-bs-toggle="tab" data-bs-target="#students" type="button" role="tab">My Students</button>
      </li>
      <li class="nav-item">
        <button class="nav-link" id="lockers-tab" data-bs-toggle="tab" data-bs-target="#lockers" type="button" role="tab">Locker Bookings</button>
      </li>
    </ul>


    <div class="tab-content" id="parentTabsContent">
>
<div class="tab-pane fade show active" id="students" role="tabpanel">
  <h5>My Students</h5>
  <button class="btn btn-danger mb-3" data-bs-toggle="modal" data-bs-target="#addStudentModal">➕ Add Student</button>
  

  <div id="studentsTableWrapper">
    <table class="table table-bordered table-striped text-center">
      <thead class="table-danger">
        <tr>
          <th>Name</th>
          <th>Surname</th>
          <th>Grade</th>
          <th>Date of Birth</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody id="studentsTableBody">
      </tbody>
    </table>
  </div>
</div>

<div class="modal fade" id="lockerLoading" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content locker-loading">
      <div class="modal-body text-center">
        <div class="locker-spinner"></div>
        <h5 class="mt-3">Unlocking Locker…</h5>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="lockerConfirm" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content locker-alert">
      <div class="modal-header locker-header">
        <h5 class="modal-title">Confirm Action</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body text-center">
        <p id="lockerConfirmMessage">Are you sure?</p>
        <div class="mt-3">
          <button id="lockerConfirmYes" class="btn btn-danger me-2">Yes</button>
          <button id="lockerConfirmNo" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="lockerAlert" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content locker-alert">
      <div class="modal-header locker-header">
        <h5 class="modal-title" id="lockerAlertTitle">Locker Alert</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="lockerAlertMessage">
        Default Locker.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="applyLockerModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content locker-alert">
      <div class="modal-header locker-header">
        <h5 class="modal-title">Apply for Locker</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <p><strong>Student:</strong> <span id="applyLockerStudentName"></span></p>
        <p><strong>Grade:</strong> <span id="applyLockerStudentGrade"></span></p>
        <input type="hidden" id="applyLockerStudentID">

        <div class="mb-3">
          <label for="availableLockerSelect" class="form-label">Select Available Locker</label>
          <select id="availableLockerSelect" class="form-control"></select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" onclick="submitLockerBooking()">Apply</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="addStudentModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-danger text-white">
        <h5 class="modal-title">Add Student</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <form id="addStudentForm">
          <div class="mb-2"><input type="text" name="Name" class="form-control" placeholder="Name" required></div>
          <div class="mb-2"><input type="text" name="Surname" class="form-control" placeholder="Surname" required></div>
          <div class="mb-2">
            <select name="Grade" class="form-control" required>
              <option value="">Select Grade</option>
              <option>8</option>
              <option>9</option>
              <option>10</option>
              <option>11</option>
              <option>12</option>
            </select>
          </div>
          <div class="mb-2"><input type="date" name="DateOfBirth" class="form-control" required></div>
          <button type="submit" class="btn btn-danger w-100">Save</button>
        </form>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="editStudentModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-warning text-dark">
        <h5 class="modal-title">Edit Student</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <form id="editStudentForm">
          <input type="hidden" name="StudentID" id="editStudentID">
          <div class="mb-2"><input type="text" name="Name" id="editName" class="form-control" placeholder="Name" required></div>
          <div class="mb-2"><input type="text" name="Surname" id="editSurname" class="form-control" placeholder="Surname" required></div>
          <div class="mb-2">
            <select name="Grade" id="editGrade" class="form-control" required>
              <option value="">Select Grade</option>
              <option>8</option>
              <option>9</option>
              <option>10</option>
              <option>11</option>
              <option>12</option>
            </select>
          </div>
          <div class="mb-2"><input type="date" name="DateOfBirth" id="editDOB" class="form-control" required></div>
          <button type="submit" class="btn btn-warning w-100">Update Student</button>
        </form>
      </div>
    </div>
  </div>
</div>

<div class="tab-pane fade" id="lockers" role="tabpanel">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Locker Bookings</h5>
    <button class="btn btn-danger" id="refreshLockersBtn">
      <i class="bi bi-arrow-clockwise"></i> Refresh
    </button>
  </div>

  <div class="input-group mb-3">
    <span class="input-group-text"><i class="bi bi-search"></i></span>
    <input type="text" id="lockerSearch" class="form-control" placeholder="Search student or locker...">
  </div>


  <div id="lockerBookingsWrapper" class="table-responsive">
    <div class="text-center text-muted py-4">
      <p>Select “Locker Bookings” above to view available lockers.</p>
    </div>
  </div>
</div>


<div class="modal fade" id="applyLockerModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-danger text-white">
        <h5 class="modal-title">Apply for Locker</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <form id="applyLockerForm">
          <input type="hidden" name="StudentID" id="applyStudentID">
          <div class="mb-3">
            <label class="form-label">Select Available Locker</label>
            <select name="LockerID" id="lockerSelect" class="form-control" required>
              <option value="">Loading lockers...</option>
            </select>
          </div>
          <button type="submit" class="btn btn-danger w-100">Submit Application</button>
        </form>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="applyLockerModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content locker-alert">
      <div class="modal-header locker-header">
        <h5 class="modal-title">Apply for Locker</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <form id="applyLockerForm">
          <input type="hidden" name="StudentID" id="applyLockerStudentID">
          <div class="mb-2"><strong>Student:</strong> <span id="applyLockerStudentName"></span></div>
          <div class="mb-3"><strong>Grade:</strong> <span id="applyLockerStudentGrade"></span></div>
          <div class="mb-3">
            <label for="availableLockerSelect" class="form-label">Select Locker</label>
            <select id="availableLockerSelect" name="LockerID" class="form-control" required></select>
          </div>
          <button type="button" class="btn btn-danger w-100" onclick="submitLockerBooking()">Confirm Booking</button>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- ====================== -->
<!-- PAYMENT MODAL -->
<!-- ====================== -->
<div class="modal fade" id="paymentModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-danger text-white">
        <h5 class="modal-title">Locker Payment</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body">
        <p id="paymentStudentInfo" class="fw-bold text-center text-danger"></p>

        <input type="hidden" id="paymentBookingID">

        <div class="mb-3">
          <label class="form-label">Card Type</label>
          <select id="paymentCardType" class="form-select">
            <option value="">Select...</option>
            <option value="Visa">Visa</option>
            <option value="MasterCard">MasterCard</option>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">Card Number</label>
          <input type="text" id="paymentCardNumber" class="form-control" maxlength="16" placeholder="0000 0000 0000 0000">
        </div>

        <div class="row">
          <div class="col">
            <label class="form-label">Expiry</label>
            <input type="text" id="paymentExpiry" class="form-control" placeholder="MM/YY">
          </div>
          <div class="col">
            <label class="form-label">CVV</label>
            <input type="text" id="paymentCVV" class="form-control" maxlength="3" placeholder="123">
          </div>
        </div>
      </div>

      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-danger" id="confirmPaymentBtn">
          <i class="bi bi-check-circle"></i> Pay Now
        </button>
      </div>
    </div>
  </div>
</div>


    </div>
  </div>
</body>
</html>
