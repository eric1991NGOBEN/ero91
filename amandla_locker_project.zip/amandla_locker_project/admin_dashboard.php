<?php
session_start();
if (!isset($_SESSION['AdminID'])) {
  header("Location: index.php");
  exit;
}

$adminEmail = $_SESSION['AdminEmail'];
$adminName = $_SESSION['AdminName'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Amandla High School Locker System - Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
        <!-- JS FILE FOR ADMIN LOGIC -->
  <script src="./js/admin.js"></script>
  <style>
    body {
      background: linear-gradient(135deg, #eec6c6ff, #f5f5f5);
      font-family: 'Edu SA Beginner', cursive;
      min-height: 100vh;
      padding: 20px;
    }
    .dashboard-card {
      background: #fff;
      border-radius: 15px;
      padding: 25px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.15);
      max-width: 1100px;
      margin: auto;
    }
    .system-title {
      font-size: 1.8rem;
      font-weight: bold;
      color: #b71c1c;
      text-align: center;
    }
    .nav-tabs .nav-link.active {
      background-color: #b71c1c !important;
      color: #fff !important;
      border-radius: 10px 10px 0 0;
    }
    .nav-tabs .nav-link {
      font-weight: bold;
      color: #b71c1c;
    }
    .tab-content {
      margin-top: 25px;
    }
    footer {
      margin-top: 40px;
      text-align: center;
      font-size: 0.9rem;
      color: #777;
    }
  </style>
</head>
<body>
  <div class="dashboard-card">
    <div class="system-title">Amandla High School<br>Locker System (Admin)</div>

    <div class="text-center mb-3">
      <h5>Welcome, <?php echo htmlspecialchars($adminName); ?></h5>
      <a href="logout_admin.php" class="btn btn-outline-danger btn-sm">Logout</a>
    </div>

    <!-- ====================== -->
    <!-- NAVIGATION TABS -->
    <!-- ====================== -->
    <ul class="nav nav-tabs justify-content-center" id="adminTabs" role="tablist">
      <li class="nav-item">
        <button class="nav-link active" id="dashboard-tab" data-bs-toggle="tab" data-bs-target="#dashboard" type="button" role="tab">
          <i class="bi bi-speedometer2"></i> Dashboard
        </button>
      </li>
      <li class="nav-item">
        <button class="nav-link" id="bookings-tab" data-bs-toggle="tab" data-bs-target="#bookings" type="button" role="tab">
          <i class="bi bi-book"></i> Locker Bookings
        </button>
      </li>
      <li class="nav-item">
  <button class="nav-link" id="waitinglist-tab" data-bs-toggle="tab" data-bs-target="#waitinglist" type="button" role="tab">
    <i class="bi bi-clock-history"></i> Waiting List
  </button>
</li>

      <li class="nav-item">
        <button class="nav-link" id="lockers-tab" data-bs-toggle="tab" data-bs-target="#lockers" type="button" role="tab">
          <i class="bi bi-door-closed"></i> Lockers
        </button>
      </li>
      <li class="nav-item">
        <button class="nav-link" id="students-tab" data-bs-toggle="tab" data-bs-target="#students" type="button" role="tab">
          <i class="bi bi-people"></i> Students
        </button>
      </li>
      <li class="nav-item">
        <button class="nav-link" id="parents-tab" data-bs-toggle="tab" data-bs-target="#parents" type="button" role="tab">
          <i class="bi bi-person-vcard"></i> Parents
        </button>
      </li>
      <li class="nav-item">
        <button class="nav-link" id="reports-tab" data-bs-toggle="tab" data-bs-target="#reports" type="button" role="tab">
          <i class="bi bi-bar-chart-line"></i> Reporting
        </button>
      </li>
    </ul>

    <div class="tab-content" id="adminTabsContent">

      <!-- ====================== -->
      <!-- DASHBOARD TAB CONTENT -->
      <!-- ====================== -->
      <div class="tab-pane fade show active" id="dashboard" role="tabpanel">
        <h5 class="mb-3 text-danger">Dashboard Overview</h5>

        <div class="row g-3 text-center">
          <div class="col-md-4">
            <div class="card shadow-sm border-dark">
              <div class="card-body">
                <h6 class="text-muted">Admins</h6>
                <h3 id="count-total-admins" class="text-dark fw-bold">0</h3>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="card shadow-sm border-warning">
              <div class="card-body">
                <h6 class="text-muted">Active Waiting List</h6>
                <h3 id="count-active-waiting" class="text-warning fw-bold">0</h3>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="card shadow-sm border-secondary">
              <div class="card-body">
                <h6 class="text-muted">Total Lockers</h6>
                <h3 id="count-total-lockers" class="text-secondary fw-bold">0</h3>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="card shadow-sm border-success">
              <div class="card-body">
                <h6 class="text-muted">Booked Lockers</h6>
                <h3 id="count-booked-lockers" class="text-success fw-bold">0</h3>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="card shadow-sm border-primary">
              <div class="card-body">
                <h6 class="text-muted">Parents</h6>
                <h3 id="count-total-parents" class="text-primary fw-bold">0</h3>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="card shadow-sm border-info">
              <div class="card-body">
                <h6 class="text-muted">Students</h6>
                <h3 id="count-total-students" class="text-info fw-bold">0</h3>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- ====================== -->
      <!-- LOCKERS TAB CONTENT -->
      <!-- ====================== -->
      <div class="tab-pane fade" id="lockers" role="tabpanel">
        <div class="d-flex justify-content-between align-items-center mb-3 mt-2">
          <h5 class="text-danger mb-0">Lockers Management</h5>
          <button class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#addLockerModal">
            <i class="bi bi-plus-circle"></i> Add Locker
          </button>
        </div>
        <div id="adminLockersContainer" class="py-3"></div>
      </div>
<!-- ====================== -->
<!-- REPORTING TAB CONTENT -->
<!-- ====================== -->
<div class="tab-pane fade" id="reports" role="tabpanel">
  <div class="d-flex justify-content-between align-items-center mb-3 mt-2">
    <h4 class="fw-bold text-danger mb-0">
      <i class="bi bi-bar-chart-fill me-2"></i> Management Information Reports
    </h4>
    <button class="btn btn-outline-danger btn-sm d-flex align-items-center gap-2 shadow-sm" id="exportXMLBtn" type="button">
      <i class="bi bi-filetype-xml fs-5"></i>
      <span class="fw-semibold">Export XML</span>
    </button>
  </div>

  <div id="reportsContainer" class="py-4 text-center text-muted">
    <i class="bi bi-hourglass-split fs-2"></i><br>
    Generating reports...
  </div>
</div>

<!-- ====================== -->
<!-- BOOKINGS TAB CONTENT -->
<!-- ====================== -->
<div class="tab-pane fade" id="bookings" role="tabpanel">
  <h5 class="mb-3 text-danger">Locker Bookings Management</h5>
  <div id="adminBookingsContainer" class="text-center text-muted py-4">
    <i class="bi bi-hourglass-split"></i> Loading bookings...
  </div>
</div>
<!-- ====================== -->
<!-- WAITING LIST TAB CONTENT -->
<!-- ====================== -->
<div class="tab-pane fade" id="waitinglist" role="tabpanel">
  <h5 class="mb-3 text-danger">Locker Waiting List</h5>
  <div id="adminWaitingListContainer" class="text-center text-muted py-4">
    <i class="bi bi-hourglass-split"></i> Loading waiting list...
  </div>
</div>
      <!-- ====================== -->
      <!-- STUDENTS TAB CONTENT -->
      <!-- ====================== -->
      <div class="tab-pane fade" id="students" role="tabpanel">
        <div class="d-flex justify-content-between align-items-center mb-3 mt-2">
          <h5 class="text-danger mb-0">Students Management</h5>
          <button class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#addStudentModal">
            <i class="bi bi-plus-circle"></i> Add Student
          </button>
        </div>
        <div id="adminStudentsContainer" class="py-3"></div>
      </div>

      <!-- ====================== -->
      <!-- PARENTS TAB CONTENT -->
      <!-- ====================== -->
      <div class="tab-pane fade" id="parents" role="tabpanel" aria-labelledby="parents-tab">
        <div class="d-flex justify-content-between align-items-center mb-3 mt-2">
          <h5 class="text-danger mb-0">Parents Management</h5>
        </div>
        <div id="adminParentsContainer" class="py-3"></div>
      </div>

    </div>
  </div>

  <!-- ====================== -->
  <!-- LOCKER MODALS -->
  <!-- ====================== -->
  <!-- Add Locker -->
  <div class="modal fade" id="addLockerModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bg-danger text-white">
          <h5 class="modal-title">Add New Locker</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form id="addLockerForm">
            <div class="mb-3">
              <label class="form-label">Physical Location</label>
              <input type="text" id="newLockerLocation" class="form-control" placeholder="e.g. Block A, Floor 2, Locker 5">
            </div>
            <div class="mb-3">
              <label class="form-label">Grade</label>
              <select id="newLockerGrade" class="form-select">
                <option value="">Select Grade</option>
                <option value="8">Grade 8</option>
                <option value="9">Grade 9</option>
                <option value="10">Grade 10</option>
                <option value="11">Grade 11</option>
                <option value="12">Grade 12</option>
              </select>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-danger" id="saveNewLockerBtn">Add Locker</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Edit Locker -->
  <div class="modal fade" id="editLockerModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bg-danger text-white">
          <h5 class="modal-title">Edit Locker</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form id="editLockerForm">
            <input type="hidden" id="editLockerId">
            <div class="mb-3">
              <label class="form-label">Physical Location</label>
              <input type="text" id="editLockerLocation" class="form-control">
            </div>
            <div class="mb-3">
              <label class="form-label">Grade</label>
              <select id="editLockerGrade" class="form-select">
                <option value="8">Grade 8</option>
                <option value="9">Grade 9</option>
                <option value="10">Grade 10</option>
                <option value="11">Grade 11</option>
                <option value="12">Grade 12</option>
              </select>
            </div>
            <div class="mb-3">
              <label class="form-label">Status</label>
              <select id="editLockerStatus" class="form-select">
                <option value="Available">Available</option>
                <option value="Booked">Booked</option>
                <option value="Pending Payment">Pending Payment</option>
                <option value="Cancelled">Cancelled</option>
              </select>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-danger" id="saveLockerBtn">Save Changes</button>
        </div>
      </div>
    </div>
  </div>
<div class="tab-pane fade" id="reports" role="tabpanel">
  <h5 class="text-danger mb-3 mt-2">Management Information Reports</h5>
  <div id="reportsContainer" class="py-3 text-center text-muted">Loading reports...</div>
</div>
  <!-- Delete Locker -->
  <div class="modal fade" id="deleteLockerModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header bg-danger text-white">
          <h5 class="modal-title">Delete Locker</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center">
          <input type="hidden" id="deleteLockerId">
          <p>Are you sure you want to delete this locker?</p>
        </div>
        <div class="modal-footer justify-content-center">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-danger" id="confirmDeleteLocker">Delete</button>
        </div>
      </div>
    </div>
  </div>

  <!-- ====================== -->
  <!-- STUDENT MODALS -->
  <!-- ====================== -->
  <div class="modal fade" id="addStudentModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bg-danger text-white">
          <h5 class="modal-title">Add New Student</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form id="addStudentForm">
            <div class="mb-3">
              <label class="form-label">Parent</label>
              <select id="newStudentParentId" class="form-select">
                <option value="">Loading parents...</option>
              </select>
            </div>
            <div class="mb-3">
              <label class="form-label">Name</label>
              <input type="text" id="newStudentName" class="form-control" placeholder="Enter first name">
            </div>
            <div class="mb-3">
              <label class="form-label">Surname</label>
              <input type="text" id="newStudentSurname" class="form-control" placeholder="Enter surname">
            </div>
            <div class="mb-3">
              <label class="form-label">Grade</label>
              <select id="newStudentGrade" class="form-select">
                <option value="">Select Grade</option>
                <option value="8">Grade 8</option>
                <option value="9">Grade 9</option>
                <option value="10">Grade 10</option>
                <option value="11">Grade 11</option>
                <option value="12">Grade 12</option>
              </select>
            </div>
            <div class="mb-3">
              <label class="form-label">Date of Birth</label>
              <input type="date" id="newStudentDob" class="form-control">
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-danger" id="saveNewStudentBtn">Add Student</button>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="editStudentModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bg-danger text-white">
          <h5 class="modal-title">Edit Student</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form id="editStudentForm">
            <input type="hidden" id="editStudentId">
            <div class="mb-3">
              <label class="form-label">Name</label>
              <input type="text" id="editStudentName" class="form-control">
            </div>
            <div class="mb-3">
              <label class="form-label">Surname</label>
              <input type="text" id="editStudentSurname" class="form-control">
            </div>
            <div class="mb-3">
              <label class="form-label">Grade</label>
              <select id="editStudentGrade" class="form-select">
                <option value="8">Grade 8</option>
                <option value="9">Grade 9</option>
                <option value="10">Grade 10</option>
                <option value="11">Grade 11</option>
                <option value="12">Grade 12</option>
              </select>
            </div>
            <div class="mb-3">
              <label class="form-label">Date of Birth</label>
              <input type="date" id="editStudentDob" class="form-control">
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-danger" id="saveStudentBtn">Save Changes</button>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="deleteStudentModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header bg-danger text-white">
          <h5 class="modal-title">Delete Student</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center">
          <input type="hidden" id="deleteStudentId">
          <p>Are you sure you want to delete this student?</p>
        </div>
        <div class="modal-footer justify-content-center">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-danger" id="confirmDeleteStudent">Delete</button>
        </div>
      </div>
    </div>
  </div>

  <!-- ====================== -->
  <!-- PARENT MODALS -->
  <!-- ====================== -->
  <div class="modal fade" id="editParentModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bg-danger text-white">
          <h5 class="modal-title">Edit Parent</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form id="editParentForm">
            <input type="hidden" id="editParentId">
            <div class="mb-3">
              <label class="form-label">Name</label>
              <input type="text" id="editParentName" class="form-control">
            </div>
            <div class="mb-3">
              <label class="form-label">Surname</label>
              <input type="text" id="editParentSurname" class="form-control">
            </div>
            <div class="mb-3">
              <label class="form-label">Email</label>
              <input type="email" id="editParentEmail" class="form-control">
            </div>
            <div class="mb-3">
              <label class="form-label">Cellphone</label>
              <input type="text" id="editParentCell" class="form-control">
            </div>
            <div class="mb-3">
              <label class="form-label">City</label>
              <input type="text" id="editParentCity" class="form-control">
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-danger" id="saveParentBtn">Save Changes</button>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="deleteParentModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header bg-danger text-white">
          <h5 class="modal-title">Delete Parent</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center">
          <input type="hidden" id="deleteParentId">
          <p>Are you sure you want to delete this parent and all linked students?</p>
        </div>
        <div class="modal-footer justify-content-center">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-danger" id="confirmDeleteParent">Delete</button>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="viewLinkedStudentsModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header bg-danger text-white">
          <h5 class="modal-title">Linked Students</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body" id="linkedStudentsContainer">
          <p class="text-muted text-center">Loading...</p>
        </div>
      </div>
    </div>
  </div>


</body>
